/usr/bin/xcrun() {
  [[ "$*" == "--sdk macosx --show-sdk-path" ]] || return 125
  printf "%s\n" "$*" >> /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/calls
  local sdk_status=0
  DEVELOPER_DIR=/private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/unconfigured-developer command /usr/bin/sandbox-exec -f /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/contained.sb /usr/bin/xcrun "$@" > /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/invocation.stdout 2> /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/invocation.stderr || sdk_status=$?
  cat /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/invocation.stdout
  cat /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/invocation.stderr >&2
  printf "%s\n" "$sdk_status" > /private/tmp/pw-build-refusals-xcbgjv3g/developer-without-sdk/invocation.status
  return "$sdk_status"
}
