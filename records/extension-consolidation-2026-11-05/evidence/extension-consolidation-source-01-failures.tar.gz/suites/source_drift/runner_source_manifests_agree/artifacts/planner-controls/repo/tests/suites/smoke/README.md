# smoke

Quick end-to-end checks against a built app bundle. These scripts are shared
and invoked by the BYOXPC runner suite.

## Invariants

- Runs the CLI against small fixtures using the runner selected by the suite.
- The specimen checks compare the built app's response schema with
  `docs/contract.json`, its worker identity with the generated source identity,
  and the envelope build stamp with the app's Info.plist.
- `runner_caller_auth` first exercises the selected, unmodified app and inspects
  its signing arrangement, then uses its real client in disposable, signed app
  copies under `/private/tmp`. A same-team client with a disallowed identifier
  and an ad-hoc client retain identical bytes
  across their restricted/relaxed pairs. Adding the identifier to the allowlist,
  or disabling caller authentication for the ad-hoc control, must enable the
  request and its independently observed file write. An unchanged authorized
  client must also reach each restricted service after the rejected request.

## Success criteria

- Specimen smoke scripts exit 0 and produce `result.ok=true`.
- Caller-auth success requires both positive file effects and bounded negative
  responses with marker bytes preserved through fixture process cleanup.
  Rejected clients retain protocol-2 acquisition errors until the bounded
  overall deadline, with no submission or host reply. Native rejection-route
  diagnostics must identify the target service; missing-service lookup errors,
  truncated diagnostics and a timeout without those observations remain
  equipment failures, not authorization evidence. Actual successful
  relaxed-policy runs must fail the rejection checker with both completion and
  file-effect diagnostics; a real missing-service run must fail it as equipment.
- Fixture signatures are applied inside-out and verified, retain the production
  entitlements and hardened runtime, and have independently inspected team/identifier metadata.
  The selected app's file hashes, modes, and symlink targets must remain unchanged.

## Fixtures

- `tests/fixtures/pw_runner/specimen_file_read_deny.json`

## Artifacts

`<run>` is the selected output directory: `tests/out/runs/default` for the
public command, or the explicit `PW_TEST_OUT_DIR`.

- `<run>/suites/<suite>/<test_id>/artifacts/*` (suite is `smoke` when run directly).
- Caller-auth artifacts include signing commands/metadata, modified service plists,
  requests, raw client output, before/after marker bytes, checker controls, source
  inventories, and fixture process cleanup. No runner registry installation is used.

Run:

```
./tests/run.sh --suite smoke
```

Whole-suite selection includes the opt-in caller-auth case and requires a
matching Developer ID signing identity. The ordinary specimen checks alone are:

```sh
tests/run.sh --case smoke/specimen_file_read_deny --case smoke/specimen_file_read_deny_standard
```

The caller-auth checker also requires the current response schema from both
successful XPC replies and real client-generated XPC errors. No returned step
carries a signal or drift key; rejected calls retain empty steps and absent
subprocess metadata alongside the existing authorization and file-effect
controls.
