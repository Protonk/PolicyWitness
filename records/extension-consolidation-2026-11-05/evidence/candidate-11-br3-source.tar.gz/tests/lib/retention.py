"""Run ownership, retained evidence, and the stable checkout execution lock.

Never unlink .checkout.lock: an open lock belongs to its inode, so replacing
that file would let later operations run concurrently with its current holder.
"""
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
import time
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parent))
import checkout_lock as ownership  # noqa: E402

RUN_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}')
RELEASE_TAG = re.compile(r'v\d+\.\d+\.\d+')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def read_object(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'expected a regular JSON file: {path}')
    value = json.loads(path.read_text(), object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise ValueError(f'expected a JSON object: {path}')
    return value


def relative_path(value):
    if not isinstance(value, str) or not value:
        raise ValueError('expected a nonempty relative path')
    path = PurePosixPath(value)
    if path.is_absolute() or '..' in path.parts or str(path) != value or value == '.':
        raise ValueError(f'invalid relative path: {value!r}')
    return path


def bounded_path(root, path):
    base = root / 'tests/out'
    path = Path(path)
    if not path.is_absolute():
        path = root / path
    if '..' in path.parts or (path != base and base not in path.parents):
        raise ValueError(f'output path must remain within {base}: {path}')
    if path.resolve() != path:
        raise ValueError(f'symlink redirects are not allowed in output paths: {path}')
    return path


def index_paths(root, index):
    """Validate an index before installing it, as well as when reading it."""
    try:
        if type(index.get('schema_version')) is not int or index['schema_version'] != 1 or not isinstance(index.get('runs'), list):
            raise ValueError('expected schema_version 1 and a runs array')
        paths = []
        for entry in index['runs']:
            required = {'path', 'run_id', 'reason', 'source', 'app_inventory'}
            if (not isinstance(entry, dict) or not required <= set(entry)
                    or set(entry) - required - {'release'}):
                raise ValueError('invalid retained entry fields')
            path = bounded_path(root, root / 'tests/out' / relative_path(entry['path']))
            if path.exists() and not path.is_dir():
                raise ValueError(f'retained path is not a directory: {path}')
            if path in paths:
                raise ValueError(f'duplicate retained path: {path}')
            if not isinstance(entry['run_id'], str) or not RUN_ID.fullmatch(entry['run_id']):
                raise ValueError('invalid retained run_id')
            if not isinstance(entry['reason'], str) or not entry['reason'].strip():
                raise ValueError('retained reason is required')
            if entry['source'] is not None and (not isinstance(entry['source'], str)
                    or not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', entry['source'])):
                raise ValueError('source must be a full commit hash or null')
            if entry['app_inventory'] is not None:
                bounded_path(root, path / relative_path(entry['app_inventory']))
            release = entry.get('release')
            if release is not None:
                if not isinstance(release, str) or not RELEASE_TAG.fullmatch(release):
                    raise ValueError('release must be a release tag or null (a pin)')
                if (len(Path(entry['path']).parts) != 2
                        or Path(entry['path']).parts[0] not in ('runs', 'release-acceptance')):
                    raise ValueError('only direct managed runs or acceptance output can opt into release rotation')
                if not RUN_ID.fullmatch(Path(entry['path']).name):
                    raise ValueError('invalid release run directory name')
            paths.append(path)
        return paths
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise ValueError(f'invalid retention index tests/RETAINED.json: {exc}') from exc


def load_index(root):
    try:
        index = read_object(root / 'tests/RETAINED.json')
    except (OSError, ValueError) as exc:
        raise ValueError(f'invalid retention index tests/RETAINED.json: {exc}') from exc
    return index_paths(root, index)


def atomic_json(path, value):
    """Install complete JSON on the same filesystem; never follow an output link."""
    if path.is_symlink() or path.parent.resolve() != path.parent:
        raise ValueError(f'symlink redirects are not allowed: {path}')
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, 'w') as stream:
            if path.exists():
                os.fchmod(stream.fileno(), path.stat().st_mode & 0o7777)
            stream.write(json.dumps(value, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        sync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_index(root, index):
    """Caller holds checkout_lock across read, validation and replacement."""
    index_paths(root, index)
    atomic_json(root / 'tests/RETAINED.json', index)


def overlaps(path, other):
    return path == other or path in other.parents or other in path.parents


def retained_overlap(path, retained):
    return next((other for other in retained if overlaps(path, other)), None)


def disposition(path):
    """Classify a real directory from ownership and terminal evidence, not location."""
    owner_path = path / 'owner.json'
    if not os.path.lexists(owner_path):
        return 'unmanaged'
    try:
        owner = valid_owner(path)
        started = owner['started_at_unix_ms']
        if not os.path.lexists(path / 'run.json'):
            return 'interrupted'
        run = read_object(path / 'run.json')
        finished = run['finished_at_unix_ms']
        completion = run['completion']
        if (type(run.get('schema_version')) is not int or run['schema_version'] != 1 or run.get('terminal') is not True
                or run.get('run_id') != owner['run_id'] or run.get('started_at_unix_ms') != started
                or type(finished) is not int or finished < started
                or run.get('duration_ms') != finished - started or type(run.get('ok')) is not bool
                or run['configuration']['out_dir'] != str(path)
                or not isinstance(completion, dict)
                or set(completion) != {'selected', 'completed', 'skipped', 'unrun'}
                or any(type(v) is not int or v < 0 for v in completion.values())
                or completion['selected'] != sum(completion[k] for k in ('completed', 'skipped', 'unrun'))):
            return 'ambiguous'
        cases, selected = run['case_results'], run['plan']['cases']
        if (not isinstance(cases, list) or not isinstance(selected, list)
                or len(cases) != completion['selected'] or len(selected) != len(cases)
                or run['plan']['configuration'] != run['configuration']
                or sorted(c['id'] for c in cases) != sorted(c['id'] for c in selected)
                or len({c['id'] for c in cases}) != len(cases)
                or any(c['state'] not in ('completed', 'skipped', 'unrun') for c in cases)
                or any(completion[state] != sum(c['state'] == state for c in cases)
                       for state in ('completed', 'skipped', 'unrun'))):
            return 'ambiguous'
        return 'completed'
    except (OSError, ValueError, KeyError, TypeError):
        return 'ambiguous'


def replacement_allowed(root, out, retained):
    from pytest_resources import guard
    guard(root, purpose='disposal', target=out)
    bounded_path(root, out)
    protected = retained_overlap(out, retained)
    if protected:
        raise ValueError(f'output overlaps retained path {protected}; choose a fresh output directory')
    if out.exists():
        if not out.is_dir():
            raise ValueError(f'output is not a directory: {out}')
        # A newly created empty directory has no evidence to replace.
        if not any(out.iterdir()):
            return
        state = disposition(out)
        if state != 'completed':
            remedy = ('inspect it or use --prune --apply --unfinished <name>'
                      if state in ('interrupted', 'ambiguous') else 'choose a fresh output directory')
            raise ValueError(f'refusing replacement of {state} output {out}; {remedy}')


@contextmanager
def checkout_lock(root, *, preview=False, purpose='execution'):
    """Own tests/.checkout.lock for the block; a preview only observes whether it is held.

    Acquisition, nested admission under an inherited claim and the busy
    refusal belong to tests/lib/checkout_lock.py; this yields that owner's
    scope, so a caller that launches protected children passes the held
    descriptor through it. Nothing unlocks explicitly: closing the last
    descriptor releases the lock. A preview yields whether the lock is busy
    and holds it for the block when it was free, without an owner record.
    """
    if preview:
        with ownership.preview(root) as busy:
            yield busy
        return
    with ownership.owned(root, purpose=purpose) as scope:
        yield scope


def valid_owner(path):
    owner = read_object(path / 'owner.json')
    if (type(owner.get('schema_version')) is not int or owner['schema_version'] != 1 or owner.get('out_dir') != str(path)
            or not isinstance(owner.get('run_id'), str) or not RUN_ID.fullmatch(owner['run_id'])
            or type(owner.get('started_at_unix_ms')) is not int or owner['started_at_unix_ms'] < 0):
        raise ValueError(f'no valid managed run ownership: {path}')
    return owner


@contextmanager
def acceptance_output(root, out):
    """Own acceptance through extraction, nested tests and final receipts.

    Creation takes the checkout lock. A separate lifetime lock protects the
    outer operation while allowing its child dispatcher to take that same
    checkout lock. Release cleanup probes the lifetime lock without blocking.
    """
    with checkout_lock(root):
        bounded_path(root, out)
        replacement_allowed(root, out, load_index(root))
        out.mkdir(parents=True)  # Acceptance always uses a fresh directory.
        fd = os.open(out / 'acceptance.lock', os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            owner = dict(schema_version=1, kind='release_acceptance', run_id='accept-' + uuid.uuid4().hex,
                         out_dir=str(out), started_at_unix_ms=time.time_ns() // 1_000_000)
            atomic_json(out / 'owner.json', owner)
        except BaseException:
            os.close(fd)
            raise
    try:
        yield owner
    finally:
        try:
            owner.update(terminal=True, finished_at_unix_ms=time.time_ns() // 1_000_000)
            atomic_json(out / 'owner.json', owner)
        finally:
            os.close(fd)


def prune_rows(root, retained, *, busy=False):
    base = bounded_path(root, root / 'tests/out')
    runs = bounded_path(root, base / 'runs')
    rows = []
    if runs.exists():
        if not runs.is_dir():
            raise ValueError(f'managed runs root is not a directory: {runs}')
        for path in sorted(runs.iterdir()):
            # Files are outside the pruning interface. Links are reported but
            # never traversed or removed, even when they point to a directory.
            if path.is_symlink():
                rows.append(dict(path=str(path.relative_to(base)), disposition='keep: unmanaged', reason='symlink redirect'))
                continue
            if not path.is_dir():
                continue
            protected = retained_overlap(path, retained)
            state = disposition(path)
            decision = ('keep: retained' if protected else 'delete' if state == 'completed'
                        else 'keep: active or interrupted' if busy and state == 'interrupted'
                        else 'keep: ' + state)
            from pytest_resources import guard
            try:
                guard(root, purpose='disposal', target=path)
            except (OSError, ValueError) as exc:
                decision = 'keep: ownership unresolved'
                rows.append(dict(path=str(path.relative_to(base)), disposition=decision, reason=str(exc)))
            else:
                rows.append(dict(path=str(path.relative_to(base)), disposition=decision))
    if base.exists():
        for path in sorted(base.iterdir()):
            if path == runs or not path.is_dir():
                continue
            rows.append(dict(path=str(path.relative_to(base)), disposition='keep: unmanaged',
                             reason='outside tests/out/runs', retained=bool(retained_overlap(path, retained))))
    return rows


def unfinished_row(root, name, retained):
    if not isinstance(name, str) or not RUN_ID.fullmatch(name) or name in ('.', '..'):
        raise ValueError('--unfinished requires one direct run directory name')
    path = bounded_path(root, root / 'tests/out/runs' / name)
    if retained_overlap(path, retained):
        raise ValueError(f'cannot remove retained output: {path}')
    if not path.is_dir():
        raise ValueError(f'no managed run directory: {path}')
    from pytest_resources import guard
    guard(root, purpose='disposal', target=path)
    valid_owner(path)
    state = disposition(path)
    if state not in ('interrupted', 'ambiguous'):
        raise ValueError(f'--unfinished requires interrupted or ambiguous managed output; got {state}: {path}')
    return dict(path='runs/' + name, disposition='delete', previous_disposition='keep: ' + state)


def prune(root, *, apply=False, unfinished=None):
    """Preview a read-only snapshot; apply re-evaluates under the checkout lock."""
    import shutil
    retained = load_index(root)
    if unfinished is not None:
        unfinished_row(root, unfinished, retained)
    else:
        prune_rows(root, retained)
    if not apply:
        with checkout_lock(root, preview=True) as busy:
            pass
        return {'schema_version': 1, 'apply': False, 'checkout_busy': busy,
                'runs': prune_rows(root, retained, busy=busy), 'removed': [], 'failures': []}
    with checkout_lock(root, purpose='disposal'):
        retained = load_index(root)
        rows = ([unfinished_row(root, unfinished, retained)] if unfinished is not None
                else prune_rows(root, retained))
        result = {'schema_version': 1, 'apply': True, 'checkout_busy': False,
                  'runs': rows, 'removed': [], 'failures': []}
        for row in rows:
            if row['disposition'] != 'delete':
                continue
            path = root / 'tests/out' / row['path']
            try:
                # Recheck directly before removing, including index edits.
                retained = load_index(root)
                if unfinished is not None:
                    unfinished_row(root, unfinished, retained)
                else:
                    replacement_allowed(root, path, retained)
                    if disposition(path) != 'completed':
                        raise ValueError('run no longer has valid completion evidence')
                from pytest_resources import guard, retire_closed
                guard(root, purpose='disposal', target=path)
                shutil.rmtree(path)
                retire_closed(root, path)
                result['removed'].append(row['path'])
            except (OSError, ValueError) as exc:
                result['failures'].append({'path': row['path'], 'error': str(exc)})
        return result
