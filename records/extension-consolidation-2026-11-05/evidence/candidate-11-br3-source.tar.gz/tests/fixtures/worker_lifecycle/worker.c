/* Test-only ABI producer for host lifecycle controls. No policy is compiled or
 * applied. The input text selects a fixture scenario, not a production request
 * seam. Publish payloads with the real ABI protocol. Most completed-report
 * controls wait for exit_requested; reap_ack_* instead exit behind a native
 * wait gate so acknowledgement cannot have appeared in the prior host sample. */
#include "pw_probe_runner_abi.h"
#include "pw_worker_evidence.h"
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include "../diagnostic_transport/worker.h"

int main(void) {
    struct stat st;
    /* Darwin may round the backing object to a page boundary. Match the real
     * worker's minimum-size check; map only the ABI region. */
    if (fstat(3, &st) || st.st_size < (off_t)PW_SHM_REGION_BYTES) return 90;
    void *base = mmap(NULL, PW_SHM_REGION_BYTES, PROT_READ | PROT_WRITE, MAP_SHARED, 3, 0);
    if (base == MAP_FAILED) return 91;
    pw_shm_header_t *hdr = base;
    uint8_t expected_identity[PW_SHM_ABI_IDENTITY_BYTES];
    memcpy(expected_identity, PW_WORKER_ABI_IDENTITY, sizeof(expected_identity));
#ifdef PW_MISMATCHED_IDENTITY
    expected_identity[sizeof(expected_identity) - 1] ^= 1;
#endif
    if (hdr->abi_magic != PW_SHM_ABI_MAGIC ||
        memcmp(hdr->abi_identity, expected_identity, sizeof(expected_identity)) != 0 ||
        atomic_load_explicit(&hdr->prepared, memory_order_acquire) != 1) return 92;
    char mode[128] = {0};
    size_t used = 0;
    for (;;) {
        ssize_t n = read(0, mode + used, sizeof(mode) - 1 - used);
        if (n < 0 && errno == EINTR) continue;
        if (n < 0) return 93;
        if (!n) break;
        used += (size_t)n;
        if (strchr(mode, '\n') && !strncmp(mode, "close_", 6)) {
            pw_shm_evidence_t *e = pw_evidence(base);
            if (!strncmp(mode, "close_transport_beta\n", 21)) {
                transport_record(e, 1, "transport_beta");
            }
            if (!strncmp(mode, "close_report\n", 13) || !strncmp(mode, "close_hang_report\n", 18)) {
                pw_progress(e, 2, 2, UINT32_MAX);
                pw_failure(e, 239, 987654, 1, -19, 0, 0, UINT32_MAX, 123);
                pw_diagnostic(e, "controlled child closed its input");
            }
            close(0); close(4);
            if (!strncmp(mode, "close_hang_", 11)) {
                /* Test watchdog only: catches a leaked duplicate input FD without
                 * hanging the test host forever before its sentinel starts. */
                for (int i = 0; i < 5000; i++) usleep(1000);
                return 98;
            }
            return 23;
        }
        if (strchr(mode, '\n') && !strncmp(mode, "hold_", 5)) {
            pw_progress(pw_evidence(base), 2, PW_PROGRESS_STARTED, UINT32_MAX);
            /* Independent watchdog: exit releases the pipe even for the old
             * blocking host. Its status must fail the deadline control. */
            alarm(5);
            for (;;) pause();
        }
        if (strchr(mode, '\n') && !strncmp(mode, "drain_", 6)) {
            const char *prefix = "drain_bytes\n";
            size_t total = used;
            if (memcmp(mode, prefix, strlen(prefix))) return 95;
            for (size_t i = strlen(prefix); i < used; i++) if (mode[i] != 'x') return 95;
            char bytes[4096];
            while ((n = read(0, bytes, sizeof(bytes))) != 0) {
                if (n < 0) { if (errno == EINTR) continue; return 93; }
                for (ssize_t i = 0; i < n; i++) if (bytes[i] != 'x') return 95;
                total += (size_t)n;
            }
            return total == strlen(prefix) + 200000 ? 24 : 95;
        }
        if (used == sizeof(mode) - 1) return 94;
    }
    if (!strncmp(mode, "reap_ack_", 9)) {
        char *gate = strchr(mode, '|');
        if (!gate || hdr->phase_count != 1 || hdr->step_count != 1) return 99;
        *gate++ = 0;
        int fatal = !strcmp(mode, "reap_ack_signal");
        if (!fatal && strcmp(mode, "reap_ack_clean")) return 99;
        alarm(5);
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        atomic_store_explicit(&hdr->phases[0].arrived, 1, memory_order_release);
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        while (atomic_load_explicit(&hdr->proceed, memory_order_acquire) != 1 || access(gate, F_OK)) usleep(1000);
        atomic_store_explicit(&hdr->phases[0].acknowledged, 1, memory_order_release);
        atomic_store_explicit(&hdr->proceed_observed, 1, memory_order_release);
        if (fatal) {
            signal(SIGTERM, SIG_DFL);
            kill(getpid(), SIGTERM);
            _exit(98);
        }
        pw_shm_slot_t *slot = (void *)((char *)base + PW_SHM_HEADER_BYTES);
        slot->rc = 0;
        slot->errno_val = 0;
        atomic_store_explicit(&slot->completed, 1, memory_order_release);
        atomic_store_explicit(&hdr->phases[0].completed, 1, memory_order_release);
        pw_progress(pw_evidence(base), PW_OP_FINISHED, PW_PROGRESS_RETURNED, UINT32_MAX);
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        _exit(0);
    }
    if (!strncmp(mode, "exec_payload_", 13)) {
        alarm(5);
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        atomic_store_explicit(&hdr->phases[0].arrived, 1, memory_order_release);
        while (atomic_load_explicit(&hdr->proceed, memory_order_acquire) != 1) usleep(1000);
        atomic_store_explicit(&hdr->phases[0].acknowledged, 1, memory_order_release);
        atomic_store_explicit(&hdr->proceed_observed, 1, memory_order_release);
        pw_shm_slot_t *slot = (void *)((char *)base + PW_SHM_HEADER_BYTES);
        slot->child_pid = 4242; slot->child_exit_code = 0; slot->child_term_signal = 0;
        strcpy(slot->child_stdout, "unpublished output must stay hidden");
        slot->exec_collection_stop = PW_EXEC_COLLECTION_COMPLETE;
        slot->exec_leader_exit_observed = 1; slot->exec_stdout_eof = 1; slot->exec_stderr_eof = 1;
        slot->exec_cleanup_state = PW_EXEC_CLEANUP_NOT_REQUESTED;
        slot->exec_reap_stop = PW_EXEC_REAP_REAPED;
        slot->exec_reap_wait_rc = 4242; slot->exec_reap_status = 0;
        slot->exec_valid = 1;
        if (!strcmp(mode, "exec_payload_unpublished")) {
            kill(getpid(), SIGKILL); _exit(98);
        }
        if (!strcmp(mode, "exec_payload_bad_marker")) slot->exec_valid = 2;
        if (!strcmp(mode, "exec_payload_bad_enum")) slot->exec_collection_stop = 77;
        atomic_store_explicit(&slot->completed, 1, memory_order_release);
        atomic_store_explicit(&hdr->phases[0].completed, 1, memory_order_release);
        pw_progress(pw_evidence(base), PW_OP_FINISHED, PW_PROGRESS_RETURNED, UINT32_MAX);
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        _exit(0);
    }
    if (!strcmp(mode, "phase_invalid_previous")) {
        alarm(5);
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        atomic_store_explicit(&hdr->phases[0].arrived, 1, memory_order_release);
        while (atomic_load_explicit(&hdr->proceed, memory_order_acquire) != 1) usleep(1000);
        atomic_store_explicit(&hdr->phases[0].acknowledged, 1, memory_order_release);
        atomic_store_explicit(&hdr->proceed_observed, 1, memory_order_release);
        /* Deliberately omit prior completion: the host must not collect phase 2. */
        atomic_store_explicit(&hdr->phases[1].arrived, 1, memory_order_release);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        return 0;
    }
    if (!strncmp(mode, "proceed_", 8) || !strncmp(mode, "signal_", 7) || !strncmp(mode, "ignore_proceed", 14)) {
        char *receipt = strchr(mode, '|');
        int receipt_fd = -1;
        if (receipt) { *receipt++ = 0; receipt_fd = open(receipt, O_WRONLY | O_CREAT | O_TRUNC, 0600); }
        alarm(10);
        pw_shm_evidence_t *e = pw_evidence(base);
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        pw_progress(e, PW_OP_PROCEED, PW_PROGRESS_STARTED, 0);
        atomic_store_explicit(&hdr->phases[0].arrived, 1, memory_order_release);
        if (receipt_fd >= 0) (void)write(receipt_fd, "waiting\n", 8);
        struct timespec start, now;
        clock_gettime(CLOCK_MONOTONIC, &start);
        long budget = !strncmp(mode, "proceed_expire:", 15) ? strtol(mode + 15, NULL, 10) : 5000;
        for (;;) {
            if (!strcmp(mode, "signal_awaiting_proceed")) {
                if (receipt) {
                    char gate[160]; snprintf(gate, sizeof(gate), "%s.die", receipt);
                    if (access(gate, F_OK) != 0) { usleep(1000); continue; }
                }
                kill(getpid(), SIGTERM); return 98;
            }
            if (!strcmp(mode, "ignore_proceed")) { usleep(1000); continue; }
            clock_gettime(CLOCK_MONOTONIC, &now);
            long elapsed = (now.tv_sec - start.tv_sec) * 1000 + (now.tv_nsec - start.tv_nsec) / 1000000;
            if (elapsed >= budget) {
                pw_failure(e, PW_OP_PROCEED, PW_FAILURE_PROCEED_TIMEOUT, PW_NATIVE_NONE, 0, 0, 0, 0, (uint32_t)budget);
                pw_diagnostic(e, "fixture proceed wait expired");
                atomic_store_explicit(&hdr->done, 1, memory_order_release);
                if (receipt_fd >= 0) (void)write(receipt_fd, "expired\n", 8);
                break;
            }
            if (atomic_load_explicit(&hdr->proceed, memory_order_acquire) == 1) {
                if (!strcmp(mode, "proceed_ack_gate")) {
                    if (!receipt) return 99;
                    char gate[160]; snprintf(gate, sizeof(gate), "%s.ackgate", receipt);
                    if (access(gate, F_OK) != 0) { usleep(1000); continue; }
                }
                atomic_store_explicit(&hdr->phases[0].acknowledged, 1, memory_order_release);
                atomic_store_explicit(&hdr->proceed_observed, 1, memory_order_release);
                if (receipt_fd >= 0) (void)write(receipt_fd, "ack\n", 4);
                if (!strcmp(mode, "signal_after_ack")) { kill(getpid(), SIGTERM); return 98; }
                pw_shm_slot_t *slots = (void *)((char *)base + PW_SHM_HEADER_BYTES);
                for (uint32_t i = 0; i < hdr->step_count; i++) {
                    pw_progress(e, PW_OP_ATTEMPT, PW_PROGRESS_STARTED, i);
                    slots[i].rc = 0;
                    if (slots[i].attempt_kind == PW_ATTEMPT_FILE_CREATE) {
                        int effect = open(slots[i].target, O_WRONLY | O_CREAT | O_EXCL, 0600);
                        if (effect < 0) { slots[i].rc = 1; slots[i].errno_val = errno; }
                        else { (void)write(effect, "fixture-effect", 14); close(effect); }
                    }
                    atomic_store_explicit(&slots[i].completed, 1, memory_order_release);
                }
                atomic_store_explicit(&hdr->phases[0].completed, 1, memory_order_release);
                if (receipt_fd >= 0) (void)write(receipt_fd, "attempt\n", 8);
                atomic_store_explicit(&hdr->done, 1, memory_order_release);
                break;
            }
            usleep(1000);
        }
        if (receipt_fd >= 0) close(receipt_fd);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        return 0;
    }
    if (!strcmp(mode, "early_exit")) return 17;
    pw_shm_evidence_t *e = pw_evidence(base);
    if (!strncmp(mode, "transport_", 10)) {
        transport_record(e, strstr(mode, "beta") != NULL, mode);
        if (!strcmp(mode, "transport_incompatible")) hdr->abi_identity[PW_SHM_ABI_IDENTITY_BYTES - 1] ^= 1;
        hdr->apply_rc = -1;
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        close(4);
        /* No apply claim, no fabricated attempt. Bound fixture life separately. */
        alarm(10);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        return 23;
    }
    if (!strncmp(mode, "diagnostic_", 11)) {
        static char long_text[PW_SHM_DIAGNOSTIC_BYTES + 200];
        const char *text = "controlled compiler diagnostic";
        if (!strcmp(mode, "diagnostic_missing")) text = NULL;
        if (!strcmp(mode, "diagnostic_empty")) text = "";
        if (!strcmp(mode, "diagnostic_truncated")) {
            memset(long_text, 'x', sizeof(long_text) - 1);
            text = long_text;
        }
        if (!strcmp(mode, "diagnostic_after_apply")) {
            extern void *sandbox_compile_string(const char *, void *, char **);
            extern int sandbox_apply(void *);
            char *error = NULL;
            void *profile = sandbox_compile_string("(version 1)(deny default)", NULL, &error);
            if (!profile || sandbox_apply(profile)) return 99;
            atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        } else { close(4); }
        pw_progress(e, 5, 2, UINT32_MAX);
        pw_failure(e, 5, 1, 2, 0, 0, 0, UINT32_MAX, 0);
        pw_diagnostic(e, text);
        hdr->apply_rc = -1;
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        /* CPU-only after application; tests prove text publication survives a
         * deny-default policy without new allocation or diagnostic I/O. */
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) {
            atomic_signal_fence(memory_order_seq_cst);
        }
        _exit(0);
    }
    if (!strcmp(mode, "unfamiliar") || !strcmp(mode, "zero_report")) {
        int unknown = !strcmp(mode, "unfamiliar");
        pw_progress(e, 239, 2, 17);
        pw_failure(e, unknown ? 239 : 0, unknown ? 4000000001u : 0,
                   unknown ? 77 : 0, -123, 1, 0, 17, 7654321);
        /* Unfamiliar kind/result and an observed zero errno must survive. */
        hdr->apply_rc = -1;
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        close(4);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        return 0;
    }
    if (!strcmp(mode, "started_attempt") || !strcmp(mode, "late_publication")) {
        pw_shm_slot_t *slot = (void *)((char *)base + PW_SHM_HEADER_BYTES);
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        pw_progress(e, 9, 1, 0);
        slot->rc = 12345; /* Poison: never readable until completed publication. */
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        if (!strcmp(mode, "late_publication")) {
            slot->rc = 0;
            atomic_store_explicit(&slot->completed, 1, memory_order_release);
            pw_progress(e, 9, 2, 0);
            atomic_store_explicit(&hdr->done, 1, memory_order_release);
        }
        return 0;
    }
    if (!strcmp(mode, "skip_publication")) {
        /* Deliberately violates completion-before-return for slot 1 through the
         * real publication primitives: slot 0 completes with returned progress,
         * slot 1 publishes started and returned progress but never completes,
         * then done. Requires a two-step plan. Not a production reachability claim. */
        pw_shm_slot_t *slots = (void *)((char *)base + PW_SHM_HEADER_BYTES);
        if (hdr->step_count != 2) return 94;
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        pw_progress(e, 9, 1, 0);
        slots[0].rc = 0;
        slots[0].errno_val = 0;
        snprintf(slots[0].observed_path, sizeof(slots[0].observed_path), "fixture-observation");
        atomic_store_explicit(&slots[0].completed, 1, memory_order_release);
        pw_progress(e, 9, 2, 0);
        pw_progress(e, 9, 1, 1);
        slots[1].rc = 12345; /* Poison: never readable without completed publication. */
        pw_progress(e, 9, 2, 1);
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
        if (write(4, "R", 1) != 1) return 97;
        close(4);
        while (!atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) usleep(1000);
        return 0;
    }
    int complete = !strcmp(mode, "complete_hang") || !strcmp(mode, "complete_exit_0") ||
                   !strcmp(mode, "complete_exit_17") || !strcmp(mode, "complete_signal");
    int failure = !strcmp(mode, "reported_failure_hang");
    if (!complete && !failure && strcmp(mode, "no_report_hang")) return 95;
    if (complete) {
        pw_shm_slot_t *slots = (void *)((char *)base + PW_SHM_HEADER_BYTES);
        if (hdr->step_count > PW_SHM_MAX_STEPS) return 96;
        hdr->apply_rc = 0;
        atomic_store_explicit(&hdr->applied, 1, memory_order_release);
        for (uint32_t i = 0; i < hdr->step_count; i++) {
            slots[i].rc = 0;
            slots[i].errno_val = 0;
            snprintf(slots[i].observed_path, sizeof(slots[i].observed_path), "fixture-observation");
            atomic_store_explicit(&slots[i].completed, 1, memory_order_release);
        }
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
    } else if (failure) {
        hdr->apply_rc = -1;
        atomic_store_explicit(&hdr->done, 1, memory_order_release);
    }
    /* Readiness follows publication in this fixture to make driver fault
     * controls deterministic; this is not production readiness coverage. */
    if (write(4, "R", 1) != 1) return 97;
    close(4);
    for (;;) {
        if (atomic_load_explicit(&hdr->exit_requested, memory_order_acquire)) {
            if (!strcmp(mode, "complete_exit_0")) _exit(0);
            if (!strcmp(mode, "complete_exit_17")) _exit(17);
            if (!strcmp(mode, "complete_signal")) {
                signal(SIGTERM, SIG_DFL);
                kill(getpid(), SIGTERM);
                _exit(98);
            }
        }
        usleep(1000);
    }
}
