import Darwin
import Foundation
@testable import PWRunnerCore
do {
    try runTerminationGateBoundaryControl()
    print("TERMINATION_GATE_ACCEPTED")
} catch let failure as TestFailure {
    print("CONTROL_REJECTED: " + failure.message)
    exit(73)
} catch { print("UNEXPECTED_FAILURE: \(error)"); exit(74) }
