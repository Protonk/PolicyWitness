"""Read-only bundle inspection and inventories shared by test equipment.

No signing, rebuilding, thinning, or manifest repair belongs here. Signature
verification is local codesign verification, not notarization or release
acceptance. One consistency rule reads signers: every executable must carry the
signer the controller carries, so an executable left ad hoc-signed inside a
production-signed app is refused while a copy signed ad hoc throughout, as
test equipment is, stays consistent.

The output target is checked on the bytes: every required executable, whatever
the manifest claims, and every other Mach-O the bundle delivers, found by
header (output_target.runnable_code), must be a thin arm64 Mach-O for macOS.
dSYM companions are debug data, not code. Signature, manifest, provenance and
output-target faults are collected independently, so one never hides another.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import stat
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_provenance
import output_target
import signer_check

CODESIGN = '/private/tmp/pw-release-battery-wpev_m6a/checkout/tests/out/release-acceptance/live-battery/tests/suites/dispatcher/artifact_controls/artifacts/invalid_manifest/repository/fixture-codesign'
NM = '/usr/bin/nm'
CONTROLLER = 'Contents/MacOS/policy-witness'
SERVICE = 'Contents/XPCServices/PWRunner.xpc'
EXECUTABLES = [CONTROLLER, *('Contents/MacOS/' + name for name in
    ('pw-runner-client', 'sbpl-check')),
    *(SERVICE + '/Contents/MacOS/' + name for name in
      ('PWRunner', 'pw-probe-runner', 'sb_api_validator', 'pw-probe-runner-unentitled'))]
MANIFEST = 'Contents/Resources/Evidence/manifest.json'
SYMBOLS = 'Contents/Resources/Evidence/symbols.json'
PROVENANCE = build_provenance.RECORD_PATH


def sandbox_imports(nm_output):
    """The undefined `_sandbox_*` symbols in `nm -u` output, sorted and unique."""
    names = set()
    for line in nm_output.splitlines():
        symbol = line.strip().split()[-1] if line.strip() else ''
        if symbol.startswith('_sandbox_'):
            names.add(symbol)
    return sorted(names)


# The worker times release waits and exec attempts with continuous Mach time.
# libc's clock_gettime(CLOCK_MONOTONIC) can fall back to a Unix syscall that a
# deny-default profile refuses, so the worker must not import it.
WORKER_FORBIDDEN_IMPORTS = ('_clock_gettime',)


def forbidden_worker_imports(nm_output):
    """The forbidden undefined symbols in the worker's `nm -u` output, sorted and unique."""
    names = {line.strip().split()[-1] for line in nm_output.splitlines() if line.strip()}
    return sorted(names.intersection(WORKER_FORBIDDEN_IMPORTS))


def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()


def inventory(app):
    """Include directories/modes and links without following directory symlinks.

    scandir errors propagate: an unreadable subtree must not look like an empty
    one. Timestamps are excluded so read-only inspection does not cause drift.
    """
    result = {}

    def visit(path):
        mode = path.lstat().st_mode
        entry = {'mode': mode}
        result[str(path.relative_to(app))] = entry
        if stat.S_ISLNK(mode):
            entry['symlink'] = os.readlink(path)
        elif stat.S_ISREG(mode):
            entry['sha256'] = digest(path)
        elif stat.S_ISDIR(mode):
            with os.scandir(path) as children:
                for child in sorted(children, key=lambda c: c.name):
                    visit(Path(child.path))
        else:
            raise ValueError(f'unsupported bundle file type: {path}')

    visit(app)
    return result


def changes(before, after):
    return {name: {'before': before.get(name), 'after': after.get(name)}
            for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)}


def inspect(app):
    app = Path(app).resolve()
    report = {'schema_version': 1, 'app': str(app), 'ok': False, 'errors': [],
              'signatures': [], 'manifest_entries': [], 'output_target': []}

    def error(code, path, message, **details):
        report['errors'].append(dict(code=code, path=str(path), message=message, **details))

    def contained(relative):
        path = app / relative
        if not path.resolve().is_relative_to(app):
            raise ValueError(f'path leaves selected app: {relative}')
        return path

    for relative in [*EXECUTABLES, MANIFEST, SYMBOLS, PROVENANCE, 'Contents/Info.plist', SERVICE + '/Contents/Info.plist']:
        try:
            path = contained(relative)
            if not path.is_file():
                raise ValueError('required file missing')
            if relative in EXECUTABLES and not os.access(path, os.X_OK):
                raise ValueError('required executable is not executable')
        except (OSError, ValueError) as exc:
            error('required_component', relative, str(exc))

    for relative, executable in (('Contents/Info.plist', 'policy-witness'),
                                  (SERVICE + '/Contents/Info.plist', 'PWRunner')):
        try:
            info = plistlib.loads(contained(relative).read_bytes())
            if not isinstance(info, dict) or info.get('CFBundleExecutable') != executable:
                raise ValueError(f'expected CFBundleExecutable={executable}')
            if not isinstance(info.get('CFBundleIdentifier'), str) or not info['CFBundleIdentifier']:
                raise ValueError('missing CFBundleIdentifier')
        except (OSError, ValueError, plistlib.InvalidFileException) as exc:
            error('bundle_metadata', relative, str(exc))

    # Explicit helpers plus both seals: --deep alone can miss an unsealed extra
    # tool. Never use --deep for signing.
    for relative in ['.', SERVICE, *EXECUTABLES[1:]]:
        argv = [CODESIGN, '--verify', '--strict', '--deep', str(app / relative)]
        receipt = {'path': relative, 'argv': argv, 'returncode': None}
        try:
            contained(relative)
            result = subprocess.run(argv, capture_output=True, text=True, timeout=30)
            receipt.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
            if result.returncode != 0:
                error('signature', relative, result.stderr.strip() or result.stdout.strip() or 'codesign verification failed')
        except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
            error('signature', relative, str(exc))
            receipt['error'] = str(exc)
        report['signatures'].append(receipt)

    # Signer consistency: every signed executable carries one signer, the controller's when the
    # controller is signed. An ad hoc helper inside a production-signed app is refused; an app signed
    # ad hoc throughout, or a fixture whose only signed executable is a linker-signed stub, is consistent.
    observed = {}
    try:
        signers = {}
        for relative in EXECUTABLES:
            found = signer_check.signature(contained(relative))
            observed[relative] = signer_check.facts(found)
            if found['leaf'] or found['adhoc']:
                signers[relative] = (found['leaf'], found['adhoc'])
        reference = signers.get(CONTROLLER) or next(iter(signers.values()), None)
        for relative, signer in signers.items():
            if signer != reference:
                error('signer', relative, f"signed by {signer[0] or 'ad hoc'}, not {reference[0] or 'ad hoc'} like the other signed executables")
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        error('signer', CONTROLLER, str(exc))

    # Host invariance: the XPC host never links, loads or calls libsandbox. Its
    # undefined symbols must carry no sandbox_* import; the worker and the
    # validator and issuer are the processes that touch the native API.
    host = SERVICE + '/Contents/MacOS/PWRunner'
    receipt = {'path': host, 'argv': [NM, '-u', str(app / host)], 'returncode': None, 'sandbox_symbols': []}
    try:
        contained(host)
        result = subprocess.run(receipt['argv'], capture_output=True, text=True, timeout=30)
        receipt.update(returncode=result.returncode)
        if result.returncode != 0:
            raise ValueError(result.stderr.strip() or 'nm failed')
        receipt['sandbox_symbols'] = sandbox_imports(result.stdout)
        if receipt['sandbox_symbols']:
            error('host_invariance', host, 'XPC host imports libsandbox symbols: ' + ', '.join(receipt['sandbox_symbols']))
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        error('host_invariance', host, str(exc))
        receipt['error'] = str(exc)
    report['host_invariance'] = receipt

    # Worker clock: its direct linked imports carry no forbidden clock call. A
    # failed inspection is an error, never an empty import set. Dynamic lookups
    # and library-internal calls are outside what this check can see.
    worker = SERVICE + '/Contents/MacOS/pw-probe-runner'
    receipt = {'path': worker, 'argv': [NM, '-u', str(app / worker)], 'returncode': None,
               'undefined': None, 'forbidden': []}
    try:
        contained(worker)
        result = subprocess.run(receipt['argv'], capture_output=True, text=True, timeout=30)
        receipt.update(returncode=result.returncode)
        if result.returncode != 0:
            raise ValueError(result.stderr.strip() or 'nm failed')
        receipt['undefined'] = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        receipt['forbidden'] = forbidden_worker_imports(result.stdout)
        if receipt['forbidden']:
            error('worker_clock', worker, 'worker imports a forbidden clock call: ' + ', '.join(receipt['forbidden']))
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        error('worker_clock', worker, 'worker import inspection failed: ' + str(exc))
        receipt['error'] = str(exc)
    report['worker_clock'] = receipt

    # Output target: the required executables regardless of the manifest, and every other runnable Mach-O by header, so
    # an inventory change is no bypass. A bundle that cannot be scanned is an error, never an empty inventory.
    try:
        required = [contained(relative) for relative in EXECUTABLES]
        delivered = list(dict.fromkeys([*(path for path in required if path.is_file()), *output_target.runnable_code(app)]))
        for path in delivered:
            relative = path.relative_to(app)
            observation = build_provenance.output_observation(path)
            problems = output_target.target_problems(observation)
            report['output_target'].append(dict(observation, path=str(relative), target_problems=problems))
            for problem in problems:
                error('output_target', relative, problem)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        error('output_target', '.', f'the bundle cannot be inspected for its output target: {exc}')

    manifest = None
    try:
        manifest = json.loads(contained(MANIFEST).read_bytes())
        if not isinstance(manifest, dict) or manifest.get('schema_version') != 1:
            raise ValueError('expected manifest schema_version=1')
        if manifest.get('app_binary_rel_path') != CONTROLLER:
            raise ValueError('manifest identifies a different controller')
        app_info = plistlib.loads(contained('Contents/Info.plist').read_bytes())
        if manifest.get('app_bundle_id') != app_info.get('CFBundleIdentifier'):
            raise ValueError('manifest app identity disagrees with Info.plist')
        entries = manifest.get('entries')
        if not isinstance(entries, list):
            raise ValueError('expected manifest entries array')
        seen = set()
        for entry in entries:
            relative = entry.get('rel_path') if isinstance(entry, dict) else None
            try:
                if (not isinstance(relative, str) or not relative or
                        PurePosixPath(relative).is_absolute() or '..' in PurePosixPath(relative).parts or
                        str(PurePosixPath(relative)) != relative or relative in seen):
                    raise ValueError('invalid or duplicate manifest path')
                seen.add(relative)
                expected = entry.get('sha256')
                actual = digest(contained(relative))
                record = dict(path=relative, expected=expected, actual=actual)
                report['manifest_entries'].append(record)
                if expected != actual:
                    error('manifest_hash', relative, 'manifest hash differs from bundle bytes', expected=expected, actual=actual)
            except (OSError, ValueError) as exc:
                error('manifest_entry', relative, str(exc))
        required = set(EXECUTABLES[1:]) | {SYMBOLS, PROVENANCE}
        # Every shipped augment must be inventoried too; the fixed executable
        # list above remains mandatory even if the manifest omits a helper.
        required.update(str(p.relative_to(app)) for p in (app / 'Contents/Resources/Augments').glob('*.sb'))
        for relative in sorted(required - seen):
            error('manifest_missing', relative, 'required component absent from manifest')
    except (OSError, ValueError, AttributeError, plistlib.InvalidFileException) as exc:
        error('manifest', MANIFEST, str(exc))

    # The provenance record must describe this bundle: a complete, unique output
    # inventory with valid paths, hashes equal to the manifest's and to the bytes,
    # and load-command metadata equal to what the bytes carry. A matching record
    # for another build, or a record with an incomplete list, is refused.
    try:
        contained(PROVENANCE)
        for code, path, message in build_provenance.record_problems(app, manifest if isinstance(manifest, dict) else None,
                                                                    signatures=observed):
            error(code, path, message)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        error('provenance', PROVENANCE, str(exc))
    report['ok'] = not report['errors']
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('app', type=Path)
    parser.add_argument('report', type=Path)
    args = parser.parse_args()
    result = inspect(args.app)
    args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    for issue in result['errors']:
        print(f"{issue['code']}: {issue['path']}: {issue['message']}")
    raise SystemExit(0 if result['ok'] else 1)
