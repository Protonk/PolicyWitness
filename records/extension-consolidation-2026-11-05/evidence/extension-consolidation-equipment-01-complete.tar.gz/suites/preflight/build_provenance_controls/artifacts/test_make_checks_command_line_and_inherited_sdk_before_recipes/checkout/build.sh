#!/bin/bash
printf "build reached: %s\n" "$SDKROOT"
