"""Exercise disposition test cleanup and Rust selection without launching a worker."""
from contextlib import ExitStack, redirect_stderr
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
TEST_NAME = 'disposition::tests::conflicting_status_representation_is_not_silently_resolved'


def capture_controls(out):
    spec = importlib.util.spec_from_file_location(
        'attempt_in_flight_controls', ROOT / 'tests/suites/witness_contract/check_attempt_in_flight.py')
    target = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(target)
    from run_capture import HarnessTimeout
    records = []
    for mode in ('reaped', 'client_timeout', 'unreaped', 'malformed_reap', 'malformed', 'harness_timeout',
                 'fifo_setup', 'capture_setup', 'launch_error', 'removal_error', 'metadata_error'):
        primary = (HarnessTimeout('controlled harness timeout') if mode == 'harness_timeout'
                   else ValueError('controlled capture failure'))
        setup_error = OSError('controlled FIFO setup failure')
        entered = []
        envelope = {'data': {'runner_result': {'runner_subprocess': {'pid': 42, 'reaped': True}}}}
        if mode == 'client_timeout':
            envelope = {'data': {'runner_result': {'normalized_outcome': 'xpc_timeout'}}}
        if mode == 'unreaped':
            envelope['data']['runner_result']['runner_subprocess']['reaped'] = False
        if mode == 'malformed_reap':
            envelope['data']['runner_result']['runner_subprocess']['pid'] = False

        class Capture:
            elapsed_seconds = 0

            def __init__(self, pw, artifacts, specimen, **kwargs):
                assert Path(specimen['fifo']).is_fifo()
                if mode == 'capture_setup':
                    raise primary

            def __enter__(self):
                entered.append(True)
                if mode == 'launch_error':
                    raise primary
                return self

            def __exit__(self, *args):
                pass

            def wait(self, **kwargs):
                if mode == 'harness_timeout':
                    raise primary
                return 1

            def load_json(self):
                if mode in ('malformed', 'metadata_error'):
                    raise primary
                return envelope

        stderr = io.StringIO()
        write_text = Path.write_text

        def fail_metadata(path, *args, **kwargs):
            if path.name == 'cleanup.json':
                raise OSError('controlled cleanup metadata failure')
            return write_text(path, *args, **kwargs)

        caught = None
        with ExitStack() as patches, redirect_stderr(stderr):
            patches.enter_context(patch.object(target, 'RunCapture', Capture))
            if mode == 'fifo_setup':
                patches.enter_context(patch.object(target.os, 'mkfifo', side_effect=setup_error))
            if mode == 'removal_error':
                patches.enter_context(patch.object(target.shutil, 'rmtree', side_effect=OSError('controlled removal failure')))
            if mode == 'metadata_error':
                patches.enter_context(patch.object(Path, 'write_text', fail_metadata))
            try:
                target.execute('unused', out, mode, lambda fifo: {'fifo': str(fifo)}, fifo=True)
            except Exception as exc:
                caught = exc
        work = out / mode
        (work / 'stderr.txt').write_text(stderr.getvalue())
        staging = Path(json.loads((work / 'staging.json').read_text())['staging'])
        retained = staging.exists()
        try:
            if mode == 'reaped':
                assert caught is None and not retained
            elif mode == 'fifo_setup':
                assert caught is setup_error and not entered and not retained
            elif mode == 'capture_setup':
                assert caught is primary and not entered and not retained
            elif mode in ('malformed', 'harness_timeout', 'metadata_error', 'launch_error'):
                assert caught is primary and retained, (mode, caught, retained)
                assert 'cleanup:' in stderr.getvalue(), stderr.getvalue()
            else:
                assert isinstance(caught, AssertionError) and retained, (mode, caught, retained)
            if mode != 'metadata_error':
                cleanup = json.loads((work / 'cleanup.json').read_text())
                assert cleanup['removed'] is (not retained), cleanup
            else:
                assert 'controlled cleanup metadata failure' in stderr.getvalue()
            records.append({'mode': mode, 'staging_retained': retained,
                            'primary': str(caught) if caught else None})
        finally:
            # Capture never spawns a process; only this control owns this staging.
            if staging.exists():
                shutil.rmtree(staging)
                (work / 'control-recovery.json').write_text(json.dumps({
                    'removed': True, 'basis': 'controlled capture launched no process'}) + '\n')

    # Existing evidence must be refused before even creating temporary staging.
    occupied = out / 'occupied'
    occupied.mkdir()
    receipt = occupied / 'cleanup.json'
    receipt.write_text('preserve prior evidence\n')
    with patch.object(target.tempfile, 'mkdtemp') as create:
        try:
            target.execute('unused', out, 'occupied', lambda fifo: {}, fifo=True)
        except FileExistsError:
            pass
        else:
            raise AssertionError('reused artifact directory accepted')
        create.assert_not_called()
    assert receipt.read_text() == 'preserve prior evidence\n'
    records.append({'mode': 'occupied', 'prior_evidence_preserved': True})
    (out / 'capture-controls.json').write_text(json.dumps(records, indent=2) + '\n')


def rust_wrapper_controls(out):
    """Both exact-selection wrappers reject incomplete or failed Cargo runs."""
    wrappers = (
        ('rust.disposition_reds', 'tests/suites/unit/disposition_reds.sh', (
            'disposition::tests::conflicting_status_representation_is_not_silently_resolved',
            'disposition::tests::conflicting_status_reports_the_status_rule',
            'disposition::tests::disposition_record_projects_witnessed_host_cleanup_cause',
            'disposition::tests::record_contradicting_its_basis_is_withheld',
        )),
        ('rust.byoxpc_reds', 'tests/suites/unit/byoxpc_reds.sh', (
            'runner_manager::tests::false_valued_key_does_not_satisfy_a_requirement',
            'runner_select::tests::selection_refuses_a_false_valued_required_key',
        )),
    )
    repo = out / 'fixture repo'
    for relative in (*[w[1] for w in wrappers], 'tests/lib/testlib.sh',
                     'tests/lib/python_start.sh', 'tests/lib/sdk_guard.sh'):
        destination = repo / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, destination)
    cargo = repo / 'bin/cargo'
    cargo.parent.mkdir()
    cargo.write_text('''#!/usr/bin/env -S ${PW_PYTHON} -B -S
import json, os, pathlib, sys
p = pathlib.Path(os.environ['WRAPPER_CARGO_FIXTURE'])
config = json.loads(p.read_text())
p.with_name('argv.json').write_text(json.dumps(sys.argv[1:]))
sys.stdout.write(config['stdout'])
sys.exit(config['status'])
''')
    cargo.chmod(0o755)

    def transcript(results, count=None):
        lines = [f'running {len(results) if count is None else count} tests']
        for name, outcome, message in results:
            lines.append(f'test {name} ... {outcome}')
            if message:
                lines.append(f"---- {name} stdout ----\nthread panicked: {message}")
        failed = sum(outcome == 'FAILED' for _, outcome, _ in results)
        passed = sum(outcome == 'ok' for _, outcome, _ in results)
        ignored = sum(outcome == 'ignored' for _, outcome, _ in results)
        verdict = 'FAILED' if failed else 'ok'
        lines.append(f'test result: {verdict}. {passed} passed; {failed} failed; {ignored} ignored;')
        return '\n'.join(lines) + '\n'

    records = []
    for case_id, wrapper, names in wrappers:
        # Independent names above constrain both the observed argv and the
        # supplied transcripts; no expectations are read from the wrapper.
        passing = [(name, 'ok', '') for name in names]
        mixed = [(names[0], 'FAILED', 'arbitrary assertion detail'), *passing[1:]]
        silent = [(names[0], 'FAILED', ''), *passing[1:]]
        ignored = [(names[0], 'ignored', ''), *passing[1:]]
        wrong = [('other::unselected', 'ok', ''), *passing[1:]]
        scenarios = (
            ('passing', 0, transcript(passing), 'pass', 'tests pass'),
            ('failed_zero_exit', 0, transcript(mixed), 'fail', 'test failed'),
            ('failed_without_text', 0, transcript(silent), 'fail', 'test failed'),
            ('missing_result', 0, transcript(passing[1:], count=len(names)), 'fail', 'did not run or pass'),
            ('ignored_result', 0, transcript(ignored), 'fail', 'did not run or pass'),
            ('empty', 0, transcript([]), 'fail', 'did not run or pass'),
            ('wrong_test', 0, transcript(wrong), 'fail', 'did not run or pass'),
            ('extra_test', 0, transcript([*passing, ('other::extra', 'ok', '')]), 'fail', 'unexpected test selection'),
            ('nonzero_exit', 101, transcript(passing), 'fail', 'cargo exited'),
            ('build_failure', 101, 'error: could not compile policy-witness\n', 'fail', 'did not run or pass'),
            ('missing_cargo', 127, 'cargo: not found\n', 'fail', 'did not run or pass'),
        )
        for name, status, stdout, expected_status, message in scenarios:
            work = out / case_id / name
            work.mkdir(parents=True)
            config = work / 'cargo.json'
            config.write_text(json.dumps({'stdout': stdout, 'status': status}))
            env = {k: v for k, v in os.environ.items() if not k.startswith('PW_') and k != 'BASH_ENV'}
            env.update(PATH=str(cargo.parent) + os.pathsep + env['PATH'],
                       WRAPPER_CARGO_FIXTURE=str(config), PW_TEST_OUT_DIR=str(work / 'output'),
                       PW_TEST_CASES=case_id, PW_TEST_EVENTS=str(work / 'output/events.jsonl'),
                       PW_TEST_RUN_ID='wrapper_control')
            result = subprocess.run(['bash', str(repo / wrapper)], env=env, cwd=work,
                                    stdin=subprocess.DEVNULL, capture_output=True, timeout=15)
            (work / 'wrapper.stdout').write_bytes(result.stdout)
            (work / 'wrapper.stderr').write_bytes(result.stderr)
            case_out = work / 'output/suites/unit' / case_id
            report = json.loads((case_out / 'report.json').read_text())
            assert report['status'] == expected_status and message in report['message'], (case_id, name, report)
            assert result.returncode == (0 if expected_status == 'pass' else 1), (case_id, name, result)
            argv = json.loads((work / 'argv.json').read_text())
            assert argv == ['test', '--manifest-path', str(repo / 'controller/Cargo.toml'),
                            '--bin', 'policy-witness', '--', '--include-ignored', '--exact', *names], argv
            assert (case_out / 'artifacts/cargo-test-ignored.log').read_text() == stdout
            records.append({'case': case_id, 'mode': name, 'returncode': result.returncode, 'report': report})
    (out / 'wrapper-controls.json').write_text(json.dumps(records, indent=2) + '\n')


def expected_fixture_controls(out):
    """E2: current acceptance, unsupported-envelope refusal, and named rejections.

    The expected fixture is an authored current two-step deadline model. Its raw witnesses
    and disposition claims are checked together by the independent oracle.
    Semantic rejections start from fresh copies of the accepted baseline and
    require independently expected rules. Version refusal uses an empty frame.
    """
    import copy
    sys.path.insert(0, str(ROOT / 'tests/lib'))
    import contract
    import lifecycle_contract as C
    import lifecycle_oracle as O
    from lifecycle_adapter import read_lifecycle
    from consumer import validate
    out.mkdir(parents=True, exist_ok=True)
    fixtures = ROOT / 'tests/fixtures/disposition'
    expected = json.loads((fixtures / 'current/constructed_deadline.json').read_text())
    unsupported = {'schema_version': contract.CONTROLLER_ENVELOPE - 1,
                   'kind': 'run', 'data': {}}
    records = []
    assert not O.check_record(expected), O.check_record(expected)
    assert not validate(expected), validate(expected)
    records.append({'control': 'expected_accepted', 'rejected': False})
    # Exact-version admission must refuse before the empty body produces any
    # shape or disposition findings. Each reader must reach that boundary.
    try:
        read_lifecycle(unsupported)
    except ValueError as error:
        assert 'unsupported controller envelope' in str(error), error
        adapter_error = str(error)
    else:
        raise AssertionError('lifecycle adapter interpreted an unsupported envelope')
    refused = O.check_record(unsupported)
    assert len(refused) == 1 and refused[0]['rule'] == 'D8', refused
    assert refused[0]['kind'] == 'unsupported_version', refused
    assert 'unsupported controller envelope' in refused[0]['detail'], refused
    errors = validate(unsupported)
    assert len(errors) == 1 and 'unsupported controller envelope' in errors[0], errors
    records.append({'control': 'unsupported_envelope', 'input': unsupported,
                    'rejected': True, 'adapter_error': adapter_error,
                    'findings': refused, 'errors': errors})
    loss = copy.deepcopy(expected)
    del loss['data']['runner_result']['runner_subprocess'][C.RECORD_KEY]
    findings = O.check_record(loss)
    assert any(f['kind'] == 'missing_record' for f in findings), findings
    assert any('disposition' in e for e in validate(loss))
    records.append({'control': 'current_reply_missing_record', 'rejected': True, 'findings': findings})

    def steps(e):
        return e['data']['runner_result']['runner_subprocess'][C.RECORD_KEY]['steps']

    def drop_request(e):
        del e['data']['runner_result']['runner_subprocess']['termination_request']

    def exit_beside_signal(e):
        e['data']['runner_result']['runner_subprocess']['exit_code'] = 0

    def cause_unknown(e):
        e['data']['runner_sandbox_diagnostics']['termination_cause'] = 'unknown'

    def identical_unresolved(e):
        for st in steps(e):
            st['questions']['step_boundary_reached'] = {'state': 'unresolved', 'reason': 'no_usable_progress'}

    def swapped(e):
        a, b = steps(e)
        a['questions']['step_boundary_reached'], b['questions']['step_boundary_reached'] = \
            b['questions']['step_boundary_reached'], a['questions']['step_boundary_reached']

    def swapped_with_debug_indices(e):
        swapped(e)
        for n, st in enumerate(steps(e)):
            st['debug_index'] = 100 + n
            st['questions']['step_boundary_reached']['debug'] = n

    for name, rule, change in (
            ('request_removed_cause_kept', 'D2', drop_request),
            ('exit_beside_signal_without_conflict', 'D1', exit_beside_signal),
            ('supported_cause_replaced_by_unknown', 'D7', cause_unknown),
            ('identical_unresolved_step_answers', 'D3', identical_unresolved),
            ('swapped_step_answers', 'D3', swapped),
            ('swapped_step_answers_with_debug_indices', 'D3', swapped_with_debug_indices)):
        mutated = copy.deepcopy(expected)
        change(mutated)
        (out / f'{name}.json').write_text(json.dumps(mutated, indent=2) + '\n')
        findings = O.check_record(mutated)
        assert findings, f'{name}: accepted'
        assert any(f['rule'] == rule for f in findings), (name, rule, findings)
        records.append({'control': name, 'rejected': True, 'rule': rule, 'findings': findings})
    assert not O.check_record(expected), 'baseline changed under mutation'
    (out / 'expected-fixture-controls.json').write_text(json.dumps(records, indent=2) + '\n')
    print('disposition expected-fixture controls: ok', flush=True)


def run_controls(artifacts):
    out = Path(artifacts).resolve() / 'disposition-controls'
    out.mkdir()
    capture_controls(out / 'capture')
    rust_wrapper_controls(out / 'rust')
    expected_fixture_controls(out / 'fixtures')
    # The contract skeleton's structural check plus the independent oracle's
    # self-check: every hand-reviewed example is reproduced by the claim tables,
    # a record built from it is accepted, its mutations are rejected with the
    # expected rule, and the core D-model evaluates totally. Constructed only.
    sys.path.insert(0, str(ROOT / 'tests/lib'))
    from lifecycle_oracle import self_check
    summary = self_check()
    (out / 'oracle-self-check.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(f'disposition capture, Rust wrapper and oracle controls: ok {summary}', flush=True)


if __name__ == '__main__':
    artifacts = Path(sys.argv[1]).resolve()
    artifacts.mkdir(parents=True, exist_ok=True)
    run_controls(artifacts)
