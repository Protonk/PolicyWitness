# Setup, handoff, ordering and interpretation mutation audit

Read at 2026-11-11T16:35:04.901185+00:00, run `tests/out/runs/contract-stage-two-opt-ins-20261111` (`20261111T162345Z_3d6c7242`). 6/6 selected joins credited. Whole run: {'receipt': {'path': 'tests/out/runs/contract-stage-two-opt-ins-20261111/run.json', 'sha256': '19d359c1c41665e56721c3e2e8658462332af9b316f362619242b50e3c6ecb85', 'bytes': 285708}, 'ok': True, 'case_outcome_counts': {'pass': 15}, 'completion': {'completed': 15, 'selected': 15, 'skipped': 0, 'unrun': 0}, 'artifact_integrity': {'app': '/Users/raccoon/Desktop/Security/PolicyWitness/dist/PolicyWitness.app', 'harness_errors': [], 'report_dir': 'artifact-integrity', 'unchanged': True, 'valid_before': True}, 'harness_errors': [], 'finished_at_unix_ms': 1794414755498}.

The frozen default audit remains `/private/tmp/pw-contract-stage-two-p9-audit/manifest.json`:42selected P9passes within the failed228/229default. Fresh runner-unit completion is a replacement receipt; the old failure remains recorded.

## `runner_unit/pwrunner_core_unit_executable` — credited

Replacement owning-case result for the failed default reader-corpus replay. This audit joins the named late-setup, equipment-prefix and quantity controls; the separate reader-corpus audit owns its detailed semantics.

Owners: `runner/Tests/PWRunnerCoreTests/ActorSchedulerTests.swift`, `runner/Tests/PWRunnerCoreTests/ActorReplyTests.swift`, `runner/Tests/PWRunnerCoreTests/ActorEquipmentTests.swift`, `runner/Tests/PWRunnerCoreTests/LimitsContractTests.swift`.

Observed: Fresh owning case passed after the earlier default failure. Relevant named Swift source/log joins retained; full reader-corpus semantics are independently audited by the reader owner.

## `runner_unit/exec_reader_mutations` — credited

Source-built host interpretation of constructed ABI/typed exec observations. Publication bypass and fabricated absent metadata must fail named unchanged assertions. The native fixture executes but performs no sandbox apply or actual exec child operation.

Owners: `tests/suites/runner_unit/opt_in/exec_reader_mutations.py`, `runner/Tests/PWRunnerCoreTests/ExecObservationTests.swift`, `runner/Sources/PWRunnerCore/ActorSession.swift`, `runner/Sources/PWRunnerCore/PWRunnerAttemptEvidence.swift`.

Observed: Baseline3/3 passed/exit0. decode_unpublished exits1 with exactly one absence assertion at ExecObservationTests:455; other2/3 pass. invent_absent_metadata exits1 with absence cannot become not_requested at421; other2/3 pass. Both variants reached unchanged compiled assertions; no SKIP.

Retained original source hashes compared: 98/98 equal; generated entrypoint/copy exceptions are explicit in `receipt.json`.

## `runner_unit/reaped_ack_mutation` — credited

Controlled fixture publication occurs inside the actual native wait after prior samples. Clean and SIGTERM children exercise reap, while constructed query/slot data isolate qualification. Removed reconciliation must fail clean/signal ownership assertions while ownership_lost stays accepted.

Owners: `tests/suites/runner_unit/opt_in/reaped_ack_mutation.py`, `runner/Tests/PWRunnerCoreTests/CWorkerLifecycleTests.swift`, `runner/Sources/PWRunnerCore/ActorSession.swift`.

Observed: Fixed clean/signal/ownership_lost3/3 pass/exit0. Removing one final observeAcknowledgement call exits1 with exactly clean and signal missing-ownership refusals; ownership_lost remains the sole pass1/3. Actual native waits/reaps gate publication, while query data are constructed.

Retained original source hashes compared: 54/54 equal; generated entrypoint/copy exceptions are explicit in `receipt.json`.

## `runner_unit/host_setup_oracle_sensitivity` — credited

Counterexample characterization: unchanged legacy oracle accepts three source-mutated native setup arrangements whose actual argv, descriptor modes and VM ranges are independently observed. Pass records the blind spots. Supplemental observation and suffix cleanup live only in disposable fixtures.

Owners: `tests/suites/runner_unit/host_setup_oracle_sensitivity.py`, `tests/suites/runner_unit/host_setup_controls.py`, `runner/Sources/PWRunnerCore/ActorSession.swift`.

Observed: Baseline and all three variants completed the unchanged legacy recipe; each17/17 legacy receipts accepted, with10rejected mutation-of-receipt controls. Native baseline readyfd4 is write-only and shmargv3; wrong direction records read-only fd4, wrong argv records shmfd4. Partial unmap records acquired3675920 bytes, page16384, rounded extent3686400; after owner unmap3670016 mapped bytes survive although legacy maps count0. Fixture reconfirms entire suffix, unmaps it successfully, and observes0overlap. All inspected VM queries returned no object-name right; conditional deallocation branch retains source scope.

## `runner_unit/actor_handoff_mutations` — credited

Three baselines and eight designated mutation refusals. Custody/answer/scan cases use synthetic authority bytes; native gate control uses fresh signed workers and independent reap before dependent collection, without extension calls. Timeout or unrelated compile failure earns no sensitivity credit.

Owners: `tests/suites/runner_unit/actor_handoff_mutations.py`, `runner/Tests/PWRunnerCoreTests/ActorAuthorityTests.swift`, `runner/Tests/PWRunnerCoreTests/ActorSchedulerTests.swift`, `runner/Sources/PWRunnerCore/AuthorityCustody.swift`, `runner/Sources/PWRunnerCore/ActorScheduler.swift`, `tests/fixtures/extension_controls/authority_binding.c`, `controller/tools/pw_probe_runner/pw_probe_runner.c`.

Observed: All11 commands exited without timeout. Three baselines return0; eight variants return73 at their designated marker: outbound alias, removed termination gate, shared answer, premature erase, scan-from-zero, prefix past hole, shared-word prefix, missing reset. Native gate baseline uses exact retained signed worker hash and independent reap; custody/scan controls use synthetic authority.

Retained original source hashes compared: 58/58 equal; generated entrypoint/copy exceptions are explicit in `receipt.json`.

## `witness_contract/order_barrier_mutations` — credited

Baseline component and signed CLI controls pass. Deliberate worker wait bypass and host early release must fail designated component and independent held-effect observations. Disposable app copies retain baseline ABI identity solely to reach the ordering oracle; actual modified bytes/signatures/substitution provenance are recorded separately. Native signing here is not a release submission.

Owners: `tests/suites/witness_contract/opt_in/mutations.py`, `tests/suites/witness_contract/check_ordering.py`, `tests/suites/runner_c_worker_harness/check_proceed.py`, `runner/Sources/PWRunnerCore/CWorker.swift`, `controller/tools/pw_probe_runner/pw_probe_runner.c`.

Observed: Baseline C hold501ms, no early attempt/completion, Swift1/1 and22native CLI held samples with target present/noexec. Worker bypass C control completes before release(held0,early_completion1), and all23CLI held samples show target absent plus exec connection. Host bypass fails exact early-worker-publication assertion with ack/attempt receipt, and all22CLI held samples show both effects. All three signed substituted apps inspect valid, exact binary/inventory/manifest hashes retained; cleanup process inventory empty. Baseline ABI retained deliberately and never represented as mutated-source digest.

## Scope carried into disposition

Setup-oracle sensitivity supplies independently observed counterexamples accepted by the legacy checker. Its pass is evidence of that checker limitation. Custody mutations exercise synthetic authority bytes; the gate control supplies its own native worker/reap observation. Exec interpretation uses constructed ABI/typed observations, and confirmed-reap qualification joins native wait/exit to constructed query facts.

Signed ordering copies carry recorded modified bytes and substitution provenance while retaining baseline ABI identity to reach the intended observer. The production app is inspected and compared separately. Signing/copy failures or timeouts would interrupt equipment preparation and supply no mutation-detection credit.

These finite controls establish the listed observations and checker sensitivity. Native Security outages, initial orchestration-clock nil, broad filter calibration, arbitrary XPC cap intervals and foreign signed recipients retain their separately recorded limits. The BYOXPC cases in this15-case selection are audited by their owning review, and this report lists their IDs without claiming artifact inspection.

