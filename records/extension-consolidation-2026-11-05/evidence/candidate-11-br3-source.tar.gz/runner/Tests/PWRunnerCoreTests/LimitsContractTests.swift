import Foundation
@testable import PWRunnerCore

private struct DocumentedLimit: Decodable {
    struct Check: Decodable { let path: String; let kind: String }
    let id: String
    let value: Int
    let checks: [Check]
}
private struct LimitsManifest: Decodable { let limits: [DocumentedLimit] }

func runLimitsContractTests(_ tk: TestKit) {
    tk.group("Documented limits") {
        tk.run("compiled layout and production defaults agree with inventory") {
            let root = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
                .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
            let manifest = try JSONDecoder().decode(LimitsManifest.self,
                from: Data(contentsOf: root.appendingPathComponent("docs/limits.json")))
            let worker = CWorkerInput(workerExecutablePath: "unused", policy: "", slots: [])
            let validator = ValidatorClientInput(executablePath: "unused", targetPid: 1, probes: [])
            guard let fixture = ProcessInfo.processInfo.environment["PW_LIFECYCLE_WORKER_FIXTURE"] else {
                throw TestFailure(message: "compiled C limit probe missing; run runner_unit")
            }
            let probe = Process(), pipe = Pipe()
            probe.executableURL = URL(fileURLWithPath: fixture + ".worker-limits")
            probe.standardOutput = pipe
            try probe.run()
            let output = pipe.fileHandleForReading.readDataToEndOfFile()
            probe.waitUntilExit()
            try expectEqual(probe.terminationStatus, 0)
            let native = Dictionary(uniqueKeysWithValues: String(decoding: output, as: UTF8.self)
                .split(separator: "\n").compactMap { line -> (String, Int)? in
                    let pair = line.split(separator: "=", maxSplits: 1)
                    guard pair.count == 2, let value = Int(pair[1]) else { return nil }
                    return (String(pair[0]), value)
                })
            guard let proceedWait = native["worker_proceed_wait"], let attemptBudget = native["exec_attempt_budget"] else {
                throw TestFailure(message: "compiled C probe omitted worker_proceed_wait or exec_attempt_budget")
            }
            let rejected = decodeValidatorFrames(Data(repeating: 0xff, count: 1024))
            guard let fault = rejected.fault else { throw TestFailure(message: "invalid frame accepted") }
            // Observe returned paths rather than restating the manifest's maxima.
            let retainedDepths = (0...32).compactMap { count in
                PWRunnerRequestFailure(code: "invalid_request", path: Array(repeating: "x", count: count)).path?.count
            }
            let retainedComponents = (0...256).compactMap { count in
                PWRunnerRequestFailure(code: "invalid_request", path: [String(repeating: "x", count: count)]).path?.first?.utf8.count
            }
            guard let retainedDepth = retainedDepths.max(), let retainedComponentBytes = retainedComponents.max() else {
                throw TestFailure(message: "request failure constructor retained no diagnostic paths")
            }
            let observed: [String: Int] = [
                "request_failure_path_components": retainedDepth,
                "request_failure_path_component": retainedComponentBytes,
                "policy_source": PWShmLayout.policyBytes - 1,
                "probe_steps": PWShmLayout.maxSteps,
                "phase_count": PWRunnerPhase.maximumCount,
                "phase_records": PWShmLayout.maxPhases,
                "actors": PWActorLimits.actors,
                "actor_phases": PWActorLimits.phases,
                "actor_issues": PWActorLimits.issues,
                "actor_deliveries": PWActorLimits.deliveries,
                "actor_handles": PWActorLimits.handles,
                "actor_releases": PWActorLimits.releases,
                "actor_id": PWActorLimits.identifierBytes,
                "extension_issue_target": PWActorLimits.targetBytes,
                "actor_setup_allowance": PWActorLimits.setupMs,
                "actor_execution_allowance": PWActorLimits.executionMs,
                "actor_collection_allowance": PWActorLimits.collectionMs,
                "actor_release_wait": PWActorLimits.releaseWaitMs,
                "actor_exchange_allowance": PWActorLimits.exchangeMs,
                "actor_lifetime_cutoff": PWActorLimits.lifetimeMs,
                "actor_required_entitlements": PWActorLimits.requiredEntitlements,
                "actor_entitlement_key": PWActorLimits.entitlementKeyBytes,
                "actor_termination_wait": PWActorLimits.terminationMs,
                "authority_setup_trailer": PWAuthoritySetupLayout.bytes,
                "authority_setup_cells": PWAuthoritySetupLayout.capacity,
                "authority_setup_reply": PWAuthoritySetupLayout.encodedReserve,
                "equipment_entitlement_bytes": PWEquipmentLimits.entitlementBytes,
                "equipment_inventory_bytes": PWEquipmentLimits.inventoryBytes,
                "equipment_diagnostic_bytes": PWEquipmentLimits.diagnosticBytes,
                "equipment_metadata_bytes": PWEquipmentLimits.metadataBytes,
                "equipment_static_bindings": PWEquipmentLimits.staticBindings,
                "equipment_live_inspections": PWEquipmentLimits.liveInspections,
                "equipment_entitlement_records": PWEquipmentLimits.entitlementRecords,
                "authority_slot_bytes": PWAuthorityLayout.slotBytes,
                "phase_id": requestLabelMaxBytes,
                "phase_publications": PWShmLayout.maxPhases * PWShmLayout.phaseBytes,
                "phase_collection_wait": phaseCollectionBudgetMs,
                "extension_reference": PWExtensionLimits.referenceBytes,
                "extension_token_storage": PWExtensionLimits.tokenBytes,
                "extension_token_payload": PWExtensionLimits.tokenBytes - 1,
                "fresh_read_bytes": PWExtensionLimits.freshReadBytes,
                "validator_reply_frame": ValidatorReplyLimits.frameBytes,
                "validator_records_per_query": ValidatorReplyLimits.recordsPerProbe,
                "validator_reply_bytes_per_query": ValidatorReplyLimits.frameBytes * ValidatorReplyLimits.recordsPerProbe,
                "validator_reply_step_id": ValidatorReplyLimits.stringBytes["step_id"]!,
                "validator_reply_operation": ValidatorReplyLimits.stringBytes["operation"]!,
                "validator_reply_filter_type": ValidatorReplyLimits.stringBytes["filter_type"]!,
                "validator_reply_filter_value": ValidatorReplyLimits.stringBytes["filter_value"]!,
                "validator_reply_outcome": ValidatorReplyLimits.stringBytes["outcome"]!,
                "validator_reply_error": ValidatorReplyLimits.stringBytes["error"]!,
                "policy_parameters": PWShmLayout.maxParams,
                "step_id": PWShmLayout.stepIdMax - 1,
                "attempt_target": PWShmLayout.targetMax - 1,
                "exec_arguments": PWShmLayout.maxArgv - 1,
                "exec_argument": PWShmLayout.argvBytes - 1,
                "parameter_key": PWShmLayout.paramKeyMax - 1,
                "parameter_value": PWShmLayout.paramValueMax - 1,
                "query_operation": sandboxCheckOperationMaxBytes,
                "query_filter_value": sandboxCheckFilterValueMaxBytes,
                "specimen_id": specimenIdMaxBytes,
                "request_label": requestLabelMaxBytes,
                "test_override_path": testOverridePathMaxBytes,
                "probe_plan_label": probePlanLabelMaxBytes,
                "host_exit_delay": hostExitDelayMs,
                "worker_policy_transfer": worker.policyTransferTimeoutMs,
                "worker_ready_wait": worker.readyByteTimeoutMs,
                "worker_sentinel_wait": worker.sentinelTimeoutMs,
                "worker_exit_grace": worker.exitGraceMs,
                "validator_io_wait": validator.verdictReadTimeoutMs,
                "worker_proceed_wait": proceedWait,
                "exec_attempt_budget": attemptBudget,
                "validator_release_margin": validatorReleaseMarginMs,
                "validator_io_override_floor": timeoutMsForValidator(override: 0),
                "validator_exit_grace": validator.exitGraceMs,
                "client_rpc_wait": PWRunnerWire.defaultClientTimeoutMs,
                "validator_fault_context": fault.retained_bytes,
                "exec_stream": PWShmLayout.childOutputBytes - 1,
                "worker_diagnostic": PWShmLayout.diagnosticBytes - 1,
                "compiled_profile": PWShmLayout.captureBytes,
                "observed_path": PWShmLayout.observedPathMax - 1,
                "attempt_error": PWShmLayout.errorMax - 1,
                "runner_reply_maximum": try maximalReplyEncodedSize(),
            ]
            try expectTrue(observed["worker_proceed_wait"]! > validator.verdictReadTimeoutMs
                + validator.exitGraceMs + validatorReleaseMarginMs)
            try expectTrue(PWRunnerPhase.maximumCount <= PWShmLayout.maxPhases)
            try expectEqual(PWActorLimits.phases, PWShmLayout.maxPhases)
            try expectEqual(PWExtensionLimits.tokenBytes, PWAuthorityLayout.tokenBytes)
            try expectEqual(PWShmLayout.extTargetBytes - 1, PWActorLimits.targetBytes)
            try expectEqual(PWExtensionLimits.freshReadBytes, PWShmLayout.freshReadBytes)
            try expectEqual(timeoutMsForValidator(override: nil), validator.verdictReadTimeoutMs)
            try expectEqual(timeoutMsForValidator(override: -100), 50)
            try expectEqual(timeoutMsForValidator(override: 70), 70)
            try expectEqual(timeoutMsForValidator(override: Int.max), Int.max, "fault-injection override has no ceiling")
            let owned = manifest.limits.filter { row in
                row.checks.contains { $0.kind == "value" && $0.path.hasSuffix("/LimitsContractTests.swift") }
            }
            try expectEqual(Set(owned.map { $0.id }), Set(observed.keys), "every declared Swift owner is exercised")
            for row in owned {
                try expectEqual(observed[row.id], Optional(row.value), row.id)
            }
            try expectEqual(timeoutMsForCWorker(override: nil), worker.sentinelTimeoutMs,
                            "orchestrator and driver defaults agree")
            // Configuration allowance only: the C active-time budget and host polling
            // budget have different epochs and accounting, not one shared clock.
            try expectEqual(worker.sentinelTimeoutMs - attemptBudget, 5_000,
                            "exec attempt budget leaves the publication margin inside the worker window")
        }
        tk.run("request failure paths retain whole locations or withhold them") {
            // Literal behavioral oracles remain independent of limits.json.
            let eight = Array(repeating: "x", count: 8)
            try expectEqual(PWRunnerRequestFailure(code: "invalid_request", path: eight).path, Optional(eight))
            try expectTrue(PWRunnerRequestFailure(code: "invalid_request", path: eight + ["x"]).path == nil)
            for component in [String(repeating: "x", count: 63), String(repeating: "é", count: 31) + "x"] {
                let path = ["policy", "params", component]
                try expectEqual(component.utf8.count, 63)
                try expectEqual(PWRunnerRequestFailure(code: "invalid_request", path: path).path, Optional(path))
                try expectTrue(PWRunnerRequestFailure(code: "invalid_request", path: ["policy", "params", component + "x"]).path == nil)
            }
            try expectTrue(PWRunnerRequestFailure(code: "invalid_request", path: nil).path == nil)
        }
        tk.run("rejected-frame context boundary retains raw prefix and loss metadata") {
            // Independent of limits.json: changing the inventory cannot change this oracle.
            for count in [255, 256, 257] {
                let decoded = decodeValidatorFrames(Data(repeating: 0xff, count: count))
                guard let fault = decoded.fault else { throw TestFailure(message: "invalid frame accepted") }
                try expectTrue(decoded.verdicts.isEmpty)
                try expectEqual(fault.frame_bytes, count)
                try expectEqual(fault.retained_bytes, min(count, 256))
                try expectEqual(fault.context_truncated, count > 256)
                try expectEqual(Data(base64Encoded: fault.context_b64), Data(repeating: 0xff, count: min(count, 256)))
            }
        }
    }
}
