#include <stdio.h>
int main(void) { puts("control"); return 0; }
