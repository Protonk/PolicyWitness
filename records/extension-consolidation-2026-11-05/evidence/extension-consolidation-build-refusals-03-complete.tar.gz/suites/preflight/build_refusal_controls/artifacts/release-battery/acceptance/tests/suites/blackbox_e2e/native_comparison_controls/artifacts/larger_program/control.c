#include <stdio.h>
static int work(int n) { int s = 0; for (int i = 0; i < n; i++) s += i * i; return s; }
int main(int argc, char **argv) { (void)argv; printf("%d\n", work(argc * 1000)); return 0; }
