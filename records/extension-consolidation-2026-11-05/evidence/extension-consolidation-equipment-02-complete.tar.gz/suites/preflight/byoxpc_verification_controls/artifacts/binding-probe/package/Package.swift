// swift-tools-version: 5.10
import PackageDescription
let package = Package(name: "EquipmentBindingProbe", platforms: [.macOS("26.0")], targets: [
    .target(name: "PWCWorkerShim"),
    .target(name: "PWRunnerCore", dependencies: ["PWCWorkerShim"],
            swiftSettings: [.unsafeFlags(["-enable-testing"])]),
    .executableTarget(name: "EquipmentBindingProbe", dependencies: ["PWRunnerCore"])])
