#include <stdio.h>
extern int sandbox_check(int pid, const char *op, int type, ...);
int main(void) { printf("%d\n", sandbox_check(1, "file-read-data", 0)); return 0; }
