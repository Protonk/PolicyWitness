import Foundation
let tk = TestKit()
runServiceAdmissionTests(tk)
print(tk.summary())
exit(tk.exitCode())
