enable -n echo
