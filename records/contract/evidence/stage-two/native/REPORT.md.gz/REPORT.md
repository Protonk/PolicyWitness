# P9 selected-evidence audit

Read at 2026-11-11T16:24:37.381038+00:00; run `tests/out/runs/contract-stage-two-default-20261111` (`20261111T155411Z_29ef0802`).
42 of 42 selected case joins credited here. Case status counts: `{'pass': 42}`. The separate run summary determines battery completion.

Completed default result: `ok=false`, canonical case outcomes `{'fail': 1, 'pass': 228}`, completion `{'completed': 229, 'selected': 229, 'skipped': 0, 'unrun': 0}`. Artifact integrity: `{'app': '/Users/raccoon/Desktop/Security/PolicyWitness/dist/PolicyWitness.app', 'harness_errors': [], 'report_dir': 'artifact-integrity', 'unchanged': True, 'valid_before': True}`.

The failed owning case is `runner_unit/pwrunner_core_unit_executable`: its later reader-definition corpus replay exited101. Named Swift subcontrols logged ok; `supplemental-unit-join.json` preserves their limited observations and withholds whole-case acceptance.


The selected app reports dirty `b6ce6d266ff281fafdae44c32061ceff018485bb`, build 1335, version 0.3.7. Its retained preflight provenance hash matches the current selected app. Public run envelopes inspected so far carry `development:1445cd80509c983c6894339523f9f13ad08f5e003de4cb29ce1c398527c42f28`. The execution-selection digest identifies the test family selection separately.

## Joined cases

### `run_effects/file_actions_have_exact_effects` — credited

Owners: `tests/suites/run_effects/check_file_actions.py; tests/suites/run_effects/effects.py`. Gaps: G10, G13.

Nine allowed/denied read/access/open_write/create/unlink rows compare independently retained before/after bytes and file identity, then public prediction/attempt/order. Truncation is exactly x; absent create is empty mode0600; existing create and denied writes preserve identity and bytes.

Scope: Finite selected policies, files and OS. Before/after filesystem reads are sequential external observations.

Observed: All nine rows recorded actual expected effects/predictions; successful create absent has unavailable path query while actual empty file effect succeeds. Per-row before/after byte/identity artifacts retained; exact bytes inspected in follow-up data projection.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `run_effects/exec_helper_effect_is_real` — credited

Owners: `tests/suites/run_effects/check_exec_effect.py; tests/suites/run_effects/effects.py`. Gaps: G10, G13.

Exact exec_baseline augment is shared by allowed/denied marker policies. Allowed child writes exact helper line/mode0600; denied child still spawns and exits3 with no marker. Effect checked before envelope.

Scope: Exact augmentation/policy/helper/platform example. Spawn success and file permission failure remain different observations.

Observed: Allowed child75051 exited0 with exact helper marker; denied child75084 spawned but exited3 with Operation not permitted stderr and no marker. Both differ in policy allowance while sharing exec_baseline.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `run_effects/run_installs_nothing` — credited

Owners: `tests/suites/run_effects/check_installs_nothing.py`. Gaps: G13.

Registry hash, runner-list data and user/system LaunchAgent/Daemon directory entries are identical around one ordinary read. launchctl label captures retained separately.

Scope: Selected persistent inventory and one invocation; labels are diagnostic.

Observed: Before and after selected registry/list/LaunchAgent/Daemon inventory files are byte identical, SHA2568ea67cee86a1ed704ee6455cbaee4ac6a1489ad6c7e4814fd96bbbc486dc5e5a.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_inheritance/cli` — credited

Owners: `tests/suites/runner_exec_inheritance/check.py; tests/fixtures/exec/inspection.py`. Gaps: G13.

Three fresh helper child PIDs, nonce stdout/stderr, empty environment, descriptor set0/1/2, inaccessible canary EBADF, stdin EOF. Contaminated worker has independent preexec same-PID canary/environment observation.

Scope: CLI native path and direct production-worker harness have different entry boundaries. Only inspected descriptor/environment set and selected helper are established.

Observed: Three distinct native child PIDs79546/79554/79555 each report empty environment, exact fd0/1/2, canaryfd200 EBADF9, stdinEOF. Host finished with matching published child PIDs/exit0 and no override.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_inheritance/contaminated_worker` — credited

Owners: `tests/suites/runner_exec_inheritance/check.py; tests/fixtures/exec/inspection.py`. Gaps: G13.

Three fresh helper child PIDs, nonce stdout/stderr, empty environment, descriptor set0/1/2, inaccessible canary EBADF, stdin EOF. Contaminated worker has independent preexec same-PID canary/environment observation.

Scope: CLI native path and direct production-worker harness have different entry boundaries. Only inspected descriptor/environment set and selected helper are established.

Observed: Source-built native worker harness retains three child PIDs79684/79685/79686 with empty environment/exact fd0/1/2/canaryEBADF/stdinEOF. Harness source requires the same-PID preexec positive contamination witness before production worker exec. Actual retained preexec witness PID79667 reports environment count1, canaryfd200 reads32 bytes and intended nonce; the same worker PID then reports applied/done/exit0.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_lifecycle/timeout_preserves_output_and_continues` — credited

Owners: `tests/suites/runner_exec_lifecycle/check.py; tests/fixtures/exec/control.py`. Gaps: G13.

Live P/C peers and process group observed independently; deadline requests group cleanup, owned leader reap signal9, child output survives, helpers observed stopped before fixture cleanup, later file write succeeds.

Scope: Deadline10s control with selected helper. Native launch/effects versus reported observation are joined separately.

Observed: P77929/C77941 same group; independently observed both exited at10.056s before cleanup. Host finished: exec_failed with child deadline, group SIGKILL request and leader reaped9; captured output retained; later write completed. Six independent checker mutations rejected.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_lifecycle/closed_streams_continue` — credited

Owners: `tests/suites/runner_exec_lifecycle/check_edges.py; tests/fixtures/exec/control.py`. Gaps: G13.

Independent peers/ancestry/group: closed streams keep children alive until fixture release; leader exit with descendant-held streams reaches deadline; externally killed worker leaves children alive with unpublished exec fields, synthetic gaps and no later write.

Scope: Three constructed process arrangements use native production worker; fixture intervention remains explicit. Worker death does not establish descendant disappearance.

Observed: Peers78661/78676 acknowledged stream closure, remained alive until controlled release, then exited naturally. Published exec ok/leader_exit_and_eof/no cleanup; before and after writes complete. Cleanup records all helper/worker exits and staging removal.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_lifecycle/leader_exit_descendant` — credited

Owners: `tests/suites/runner_exec_lifecycle/check_edges.py; tests/fixtures/exec/control.py`. Gaps: G13.

Independent peers/ancestry/group: closed streams keep children alive until fixture release; leader exit with descendant-held streams reaches deadline; externally killed worker leaves children alive with unpublished exec fields, synthetic gaps and no later write.

Scope: Three constructed process arrangements use native production worker; fixture intervention remains explicit. Worker death does not establish descendant disappearance.

Observed: Leader78785 exited0 while C78794 kept streams;10.087s deadline requests groupkill, both exits independently observed, published exec_failed preserves leader exit0 and missingEOF; later write completed. Cleanup fully observed.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_lifecycle/worker_dies_during_exec` — credited

Owners: `tests/suites/runner_exec_lifecycle/check_edges.py; tests/fixtures/exec/control.py`. Gaps: G13.

Independent peers/ancestry/group: closed streams keep children alive until fixture release; leader exit with descendant-held streams reaches deadline; externally killed worker leaves children alive with unpublished exec fields, synthetic gaps and no later write.

Scope: Three constructed process arrangements use native production worker; fixture intervention remains explicit. Worker death does not establish descendant disappearance.

Observed: Controlled external SIGKILL of independently identified worker75488; helper peers75490/75499 still had no exit events after CLI. Later fixture cleanup observes all exits and removes staging; before-step effect survives, later-step target unchanged.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_exec_lifecycle/closed_streams_leader_exit` — credited

Owners: `tests/suites/runner_exec_lifecycle/check_closed_streams_leader_exit.py; tests/fixtures/exec/control.py`. Gaps: G13.

Both streams closed and leader exited; after CLI clean exec publication/later write, same-group descendant still responds with same process identity and no exit event. Later fixture release produces exit; observer rejects exited child.

Scope: Observed current process-tree limit: leader exit and captured-stream EOF can coexist with a surviving descendant. Later fixture cleanup is separately recorded.

Observed: Native clean CLI0, later file x, P75356 exited while C75383 same identity/group remained responsive after CLI with no exit event. Later fixture release observed C exit; negative observer control rejects exited child; cleanup complete and owned worker75353 exit observed.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_c_worker_harness/sysctl_read_capacity` — credited

Owners: `tests/suites/runner_c_worker_harness/check_sysctl.py; tests/fixtures/worker_lifecycle/sysctl_control.c`. Gaps: G13.

Source-built production worker with substituted sysctl call supplies4096-byte buffer once with correct target/null new-value, copies success and ENOMEM;4095 mutation preserves other behavior and independent literal-capacity assertion rejects it.

Scope: Source-constructed native-call receipt. Kernel filter/sysctl behavior and production capacity duration are separate.

Observed: Baseline success/failure supplied4096 bytes once, correct target/non-null output, nullnewvalue; rc0/errno0 and rc1/errno12.4095 mutation changed capacity only and was rejected with actual sysctl read capacity is not4096. Twelve recorded source hashes joined separately.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/queries_precede_attempts` — credited

Owners: `tests/suites/witness_contract/check_removed_target.py`. Gaps: G14.

Native read then unlink retain allow predictions/rc0 and query_first/succeeded/matched/same_submitted rows after independently observing target absence; later host realpath nonresolution remains its own observation.

Scope: Current selected plans and policies. Mutation sensitivity is separate required opt-in.

Observed: Independent file-witness absent=true. Both read/unlink native predictions allow0 and completed attempts succeeded/query_first/matched/same_submitted with no limitations; later host realpath resolution null. No overrides.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/max_steps_ordered` — credited

Owners: `tests/suites/witness_contract/check_ordering.py`. Gaps: G14.

Exact native verdict/attempt rows, worker versus validator PID, complete collection/release barrier and query_first relationships; ordinary/max256/bare-deny arrangements. Independent file observations validate selected effects.

Scope: Current selected plans and policies. Mutation sensitivity is separate required opt-in.

Observed: 256 native step rows all query_first; 256 independent before/after entries alternate changed x and unchanged seeds. Main ordering chain all true, no violations, validator reaped/EOF.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/deny_default_ordered` — credited

Owners: `tests/suites/witness_contract/check_ordering.py`. Gaps: G14.

Exact native verdict/attempt rows, worker versus validator PID, complete collection/release barrier and query_first relationships; ordinary/max256/bare-deny arrangements. Independent file observations validate selected effects.

Scope: Current selected plans and policies. Mutation sensitivity is separate required opt-in.

Observed: Two denied native writes leave both independent seeds unchanged. Both rows query_first; completed collection/release chain and reaped helper retained.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/attempt_effects_wait_for_collection` — credited

Owners: `tests/suites/witness_contract/check_ordering.py::held_effects; tests/fixtures/validator/gate.py`. Gaps: G14.

Independent worker/validator ancestry; helper holds batch replies while repeated target snapshots stay unchanged and no exec peer connects. After collection release, exec peers appear and unlink effect observed before parsing report.

Scope: Held helper makes interval observable; exact phase/probe composition.

Observed: 23 held samples retain target/content and no exec connection. Independent process identities establish worker88558/validator88559 under host88557. After helper collection closes, exec child88642/grandchild88643 appear, target absent; report has both query_first with complete barrier.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/queries_use_a_pre_attempt_interval` — credited

Owners: `tests/suites/witness_contract/check_ordering.py`. Gaps: G12, G14.

Existing/missing/recreated paths and external unlink during held query interval distinguish query collection from later attempt filesystem state. Native prediction/attempt/order retained separately.

Scope: Finite path/native-filter examples. Earlier filter exploration and unresolved local-Mach mapping retain their own dates/limits.

Observed: Absent path control runs two successful attempts with prediction_unavailable/unestablished and no validator; removed control retains allow predictions while second open failsENOENT; recreated control retains three query_first completed steps. These are distinct time observations.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/query_interval_is_not_a_snapshot` — credited

Owners: `tests/suites/witness_contract/check_ordering.py`. Gaps: G12, G14.

Existing/missing/recreated paths and external unlink during held query interval distinguish query collection from later attempt filesystem state. Native prediction/attempt/order retained separately.

Scope: Finite path/native-filter examples. Earlier filter exploration and unresolved local-Mach mapping retain their own dates/limits.

Observed: External-state records removal while collection remains open. Native helper emits allow before removal then deny after removal for the same target; both records remain query_first, with actual later attempts preserved.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/external_mutation_between_query_and_attempt` — credited

Owners: `tests/suites/witness_contract/check_ordering.py`. Gaps: G12, G14.

Existing/missing/recreated paths and external unlink during held query interval distinguish query collection from later attempt filesystem state. Native prediction/attempt/order retained separately.

Scope: Finite path/native-filter examples. Earlier filter exploration and unresolved local-Mach mapping retain their own dates/limits.

Observed: Native allow verdict recorded before external removal while helper still held. Final report retains query_first and later native attempt result, so collection ordering stays distinct from mutable path state.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/phases` — credited

Owners: `tests/suites/witness_contract/check_phases.py`. Gaps: G07, G14.

Phase-local order; unlink then next-phase missing query, fresh later validator; recreated file.100ms aggregate yields first partial deadline and later budget_exhausted/no helper while attempts run; bounded stdout cutoff retained.

Scope: Ordinary phases exercise aggregate and helper override. Aggregate clamp value/unit controls and actor applicability are separate.

Observed: Ordinary unlink removes target, next-phase nohelper query unavailable, third fresh helper; recreated target is empty.100ms aggregate retains first helper partial record/deadline and later not_spawned phases while all attempts complete. Byte-limit case retains24576 received bytes and partial record with helper reap. Consumer negative mutations retained.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extensions` — credited

Owners: `tests/suites/witness_contract/check_extensions.py`. Gaps: G16, G17.

Native issue/transfer/consume/read/release with distinct actor PIDs, gated source owned reap, exact custody equal/ack relationships; before denied, during known bytes/device/inode, release result and after result recorded; exact guide example instantiated.

Scope: Selected policy, entitlement, resource, bytes and OS. Release return does not by itself establish later revocation.

Observed: Independent target device/inode/content remains unchanged. Before openEPERM, during fresh read32 bytes matches target identity/content, release0, after openEPERM observed. Guide example, symlink/replacement and63/64/65-byte prefix neighbors retained separately; selected source gate/actor ownership checked by case.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extension_policy_qualification` — credited

Owners: `tests/suites/witness_contract/check_extension_policy_qualification.py`. Gaps: G10, G16, G17.

Exact saved policy/hash compiles with shipped helper; fresh worker applies then denied baseline open; separate control policy reads known content; independent target unchanged.

Scope: Compilation, worker apply, native issuance and eventual access have separate evidence scopes.

Observed: Exact291-byte policy SHA2ab84179a596a71dee61f9fb3c0a60625b4938960006cbe7d62b2d4ee03bcc4f compiled by selected helper then worker91053 applied with denied baseline openEPERM/predictiondeny. Positive control worker91064 fresh-read31 bytes. Environment26.7.1/25.6.0arm64 retained.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extension_redelegation` — credited

Owners: `tests/suites/witness_contract/check_extension_redelegation.py`. Gaps: G16, G17.

Calibration must perform native issue/transfer/consume and fresh known-byte read. Principal credited only when every link and denied baselines succeed; selected contrasts record omissions/weakened-policy outcomes.

Scope: A passing case permits principal.credited=false. Read principal.credited and first_break before reporting re-delegation.

Observed: Principal credited=true/first_break=null. Both issues native nonnull/tokenlength215; both transfers delivered/equal/acknowledged; B and C consumes return1; known-byte reads succeed after denied baselines; both releases0. Calibration succeeds; all four contrast credited values false. Scope exact actors/policies/resource/platform.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extension_directory` — credited

Owners: `tests/suites/witness_contract/check_extension_directory.py`. Gaps: G16, G17.

Read-write/read-only/no-consume/no-predicate/different-directory cases have allow baseline and external final byte/identity observations; only native successful writes imply exact x effect. Unpublished fresh write leaves external x with synthetic missing native fields.

Scope: After-release observations retain actual values; no required revocation pattern. Cleanup ownership/reap checked before staging removal.

Observed: Five directory arrangements and their allow baselines passed. Read-write during-existing/child externally x; read-only and missing predicate/consume/different directory retain their observed denials. Release observations retained without universal revocation assertion. Unpublished-write external effect and missing native field distinction retained;11attempt cleanup records all worker exits, staging removed.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extension_boundaries` — credited

Owners: `tests/suites/witness_contract/check_extension_boundaries.py; tests/suites/witness_contract/check_extension_combinations.py; tests/fixtures/extension_controls/control.c; tests/fixtures/comparison/matrix.json`. Gaps: G07, G16, G17, G30.

Signed source-built override actors with independent shared observer prove actual returned/native result, token custody/erasure/argv/env/core/channel relationships and selected combined faults; reported binding hash/signature/live PID/path/CDHash/identifier/team associated.

Scope: Override binding is test_override/unverified_fixture. Controlled ABI publication/native failure modes are source-constructed, not spontaneous Security failures. Normal matched live association is native. Token bytes remain unretained.

Observed: All44 rows pass. Native observer records returned release0,220-byte transient token, clean argv/env, disabled core, closed channels, full16384-byte erasure and detector sensitivity. Both override actor live observations matched/eligible with all four Security statuses0; bindings explicitly test_override/unverified_fixture and null team. Controlled issue/worker/setup rows retain their exact native-return versus unpublished distinctions. All44 channel ownership records cleanup_retained=false.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/extension_combinations` — credited

Owners: `tests/suites/witness_contract/check_extension_boundaries.py; tests/suites/witness_contract/check_extension_combinations.py; tests/fixtures/extension_controls/control.c; tests/fixtures/comparison/matrix.json`. Gaps: G07, G16, G17, G30.

Signed source-built override actors with independent shared observer prove actual returned/native result, token custody/erasure/argv/env/core/channel relationships and selected combined faults; reported binding hash/signature/live PID/path/CDHash/identifier/team associated.

Scope: Override binding is test_override/unverified_fixture. Controlled ABI publication/native failure modes are source-constructed, not spontaneous Security failures. Normal matched live association is native. Token bytes remain unretained.

Observed: Seven rowsM01–M07 pass with exact matrix comparison and independent shared observer. Native token confinement detector sensitivity retained even when consume is not reached. All channel cleanup records settled; these are controlled combined faults.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/actor_compositions` — credited

Owners: `tests/suites/witness_contract/check_actor_compositions.py`. Gaps: G07, G17, G29.

Composed actors have independent fresh bytes/file identity and native custody. Failed evaluated gate cancels dependent and later unrelated phase; unavailable dependent leaves gate unreached and later eligible actor runs. Paired200ms worker timeout/500ms post-phase hang: ordinary sentinel times out/reaps clean in grace; actors use10000/120000 allowances, source reap gate and dependent read.

Scope: Selected values/cooperative policy/platform. Current global cancellation reach stays maintainer-reserved. Other integer override values retain source-defined applicability.

Observed: Four26-action composition variants retain distinct fresh PIDs/known-byte resource identity. Failed evaluated gate timedout5000 cancels dependent and unrelated phase; final all-three owned collection/reaps remain. Unreached dependent gate leaves unrelated phase activated/completed. Paired timeout200/hang500: ordinary reaps0duringgrace after200ms deadline; actor charged506ms under120000 budget, source91772 naturally reaped at gate, satisfied dependency and matching fresh-read bytes/device/inode.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/dossier_witness` — credited

Owners: `tests/suites/witness_contract/check_dossier.py; controller/src/dossier.rs; controller/src/run_flow.rs`. Gaps: G07, G11, G34.

Independent tool/host/manifest/file/hash reads; selected policy/augmentation/import copies; exact serialized delivery bytes/argv; same/different/missing worker override hashes and missing spawn; refusal envelopes.

Scope: Reads occur at separate times. Literal import scanner is bounded; selected-file hash is distinct from launched-image association. Held-input serialization control is separately owned; BYOXPC opt-in pending.

Observed: Host facts macOS26.7.1/25G241 Darwin25.6.0 arm64. Ordinary imports complete0; selected system import walk2 records and finished; exec_baseline augmentation retains distinct original/applied hashes. Worker overrides same hash→match, different /usr/bin/true copy→mismatch, missing→unavailable; selected manifest path→null delta. Controller refusal/control records retained. Independent check reads occur after controller reads.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_use_c_worker/worker_timeout_ms_honored` — credited

Owners: `tests/suites/runner_outcome_runner_timeout/check.py`. Gaps: G07.

2000ms worker timeout with8000ms post-apply hang selects host SIGKILL after completed write/emptyplan; independent changed bytes and retained completed evidence remain beside runner_timeout/exit1.

Scope: Shortened ordinary timeout seam. Default120000ms duration and all actor behavior are separate.

Observed: Native worker_timeout2000/post_apply_hang8000 produced runner_timeout/CLI1 in3.097s. Completed file write retained rc0 and independent64-byte seed→x; deadline and owned reap are distinct from completed attempt.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_outcome_runner_timeout/host_kills_hung_worker` — credited

Owners: `tests/suites/runner_outcome_runner_timeout/check.py`. Gaps: G07.

2000ms worker timeout with8000ms post-apply hang selects host SIGKILL after completed write/emptyplan; independent changed bytes and retained completed evidence remain beside runner_timeout/exit1.

Scope: Shortened ordinary timeout seam. Default120000ms duration and all actor behavior are separate.

Observed: CLI1; host runner_timeout, worker60110 reaped signal9 after sentinel_deadline. Echoed worker_timeout_ms2000/post_apply_hang8000. Explicit empty steps and no validator; elapsed3.055s.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/pre_apply_failure_reports_no_policy_verdict` — credited

Owners: `tests/suites/witness_contract/check_pre_apply_failure.py`. Gaps: G07.

Known effects baseline; pre-ready hang10000/worker200 preserves no-apply/no-verdict/unchanged file; missing worker posix_spawn failure. Excessive four argv values60001/60001/32/256 exit2 directworker and host launched/reaped/synthetic noapply records with unchanged targets.

Scope: Host admits integers; C parser supplies operational range refusal. Selected excessive endpoints, not every value/actor path.

Observed: Pre-ready10000/timeout200 produces runner_timeout without applied/validator and unchanged targets; positive knownpolicy effects pass. Missing worker spawn has no child. All four excessive argv controls return native2 (60001 posthang/preready,32signal,256slot) and host runner_failed/reaped2/no ready/done/apply with synthetic unresolved slots; retained before/after files unchanged under source assertions.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_post_apply_hang_seam` — credited

Owners: `tests/suites/runner_outcome_runner_timeout/check.py`. Gaps: G07.

Seam-specific completed versus started/unpublished versus not-reached slot observations and independently retained file effects.

Scope: Exact native seams; slot publication and external effect are separately established.

Observed: Mixed ordinary plan retains successful allowed write and denied unchanged file beside runner_timeout after worker_timeout2000/post_apply_hang8000. Completed per-step native and comparison evidence preserved by the same check as the selected write neighbor.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_attempt_in_flight_at_deadline` — credited

Owners: `tests/suites/witness_contract/check_attempt_in_flight.py`. Gaps: G07.

Seam-specific completed versus started/unpublished versus not-reached slot observations and independently retained file effects.

Scope: Exact native seams; slot publication and external effect are separately established.

Observed: a1/a3 FIFO blocks with2000ms sentinel deadline/owned signal9; prefix completed survives, FIFO started_without_result and suffix not_reached. a4 timeout300/hang800 records sentinel deadline but reaped exit0/done during grace, completed read retained; no host kill invented.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_killed_before_slot_publication` — credited

Owners: `tests/suites/witness_contract/check_killed_before_publication.py`. Gaps: G07.

Seam-specific completed versus started/unpublished versus not-reached slot observations and independently retained file effects.

Scope: Exact native seams; slot publication and external effect are separately established.

Observed: Slot1 native create effect independently retained while kill-before-publication1/timeout5000 gives owned reap9/child_reaped; prefix completed, created started_without_result and suffix not_reached. No native result is published for created slot.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_termination` — credited

Owners: `tests/suites/witness_contract/check_worker_termination.py`. Gaps: G07.

Clean and post-apply signal9 neighbors after completed denied attempts preserve unchanged target, application, owned reap and completed/query_first rows; child death is not host kill attribution.

Scope: Specific positive kill signal and ordinary process. Upper accepted C signal endpoint has parser coverage separately.

Observed: Flat and phased success versus self-signal9 pairs retain independent files and completed attempt observations. Signaled rows runner_failed/process signaled/cause unknown/stop child_reaped; success rows finished/clean_exit/null cause/done, all integrity valid.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_sparse_failure` — credited

Owners: `tests/suites/witness_contract/check_worker_sparse.py`. Gaps: G07.

Worker executable overrides and sparse/incomplete source-built ABI reports preserve available native/effect/progress facts and missing/unknown evidence; actual post-apply kill neighbor.

Scope: Source-constructed fixtures and native process seams retain separate grades; passing readers do not establish native frequency.

Observed: Actual after-probes hang1500/self-signal9 retains completed write; injected map failure and closed policy pipe fixtures retain unresolved or not_reached slots with reaped exits3/23. Fixture publication is separate from native occurrence.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/worker_progress_and_failure` — credited

Owners: `tests/suites/witness_contract/check_worker_evidence.py`. Gaps: G07.

Worker executable overrides and sparse/incomplete source-built ABI reports preserve available native/effect/progress facts and missing/unknown evidence; actual post-apply kill neighbor.

Scope: Source-constructed fixtures and native process seams retain separate grades; passing readers do not establish native frequency.

Observed: Native successful write and native compile failure neighbors plus constructed unfamiliar/missing/rich/truncated diagnostics preserve their available worker evidence and expected unresolved/not_reached lifecycle projections. Each override executable path retained.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `witness_contract/unfamiliar_diagnostic_transport` — credited

Owners: `tests/suites/witness_contract/check_diagnostic_transport.py`. Gaps: G07.

Worker executable overrides and sparse/incomplete source-built ABI reports preserve available native/effect/progress facts and missing/unknown evidence; actual post-apply kill neighbor.

Scope: Source-constructed fixtures and native process seams retain separate grades; passing readers do not establish native frequency.

Observed: Source-built unfamiliar producer variants retain opaque alpha/beta/truncated or mark absent/malformed/incompatible/unpublished evidence as unresolved; actual child reaped23. Controlled validator boolean variants retain all native worker writes with finished versus decode_failure. No spontaneous native occurrence inferred.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_validator_failure/transcript_controls` — credited

Owners: `tests/suites/runner_validator_failure/check.py; tests/fixtures/validator/validator.py`. Gaps: G07.

Direct fixture transcript pins exact probes, reverse replies/malformed tail/one reply then SIGKILL. Public host uses override; native independent write versus denied unchanged files, partial query association, complete attempt records and outcome retained.

Scope: Validator output is controlled; attempts execute actual workers. Partial replies do not supply missing native queries.

Observed: Completed direct eof/malformed/signal_after_one fixture characterization. Native integration receives credit separately in the three following cases.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_validator_failure/validator_decode_failure_reports_degraded` — credited

Owners: `tests/suites/runner_validator_failure/check.py; tests/fixtures/validator/validator.py`. Gaps: G07.

Direct fixture transcript pins exact probes, reverse replies/malformed tail/one reply then SIGKILL. Public host uses override; native independent write versus denied unchanged files, partial query association, complete attempt records and outcome retained.

Scope: Validator output is controlled; attempts execute actual workers. Partial replies do not supply missing native queries.

Observed: CLI1; decode_failure with two reversed raw records retained, malformed tail decode_fault and missing third ID. Worker64774 reaped0, all three attempts completed. Independent file lengths64→1,64→64,64→64 with latter bytes identical; orders query_first/query_first/unestablished.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_validator_failure/validator_unavailable_reports_degraded` — credited

Owners: `tests/suites/runner_validator_failure/check.py; tests/fixtures/validator/validator.py`. Gaps: G07.

Direct fixture transcript pins exact probes, reverse replies/malformed tail/one reply then SIGKILL. Public host uses override; native independent write versus denied unchanged files, partial query association, complete attempt records and outcome retained.

Scope: Validator output is controlled; attempts execute actual workers. Partial replies do not supply missing native queries.

Observed: CLI1; unavailable after EOF with two reversed raw records and missing third ID. Worker64872 reaped0. Independent changed allowed file and unchanged denied files; same separate prediction/attempt/order structure.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_validator_failure/validator_killed_mid_stream` — credited

Owners: `tests/suites/runner_validator_failure/check_signal.py; tests/suites/runner_validator_failure/check.py; tests/suites/witness_contract/check_ordering.py`. Gaps: G07.

Direct fixture transcript pins exact probes, reverse replies/malformed tail/one reply then SIGKILL. Public host uses override; native independent write versus denied unchanged files, partial query association, complete attempt records and outcome retained.

Scope: Validator output is controlled; attempts execute actual workers. Partial replies do not supply missing native queries.

Observed: Actual controlled helper SIGKILL9/reaped after one raw verdict; worker64957 reaped0. Three independent64-byte targets become x; orders query_first/unestablished/unestablished; missing query facts preserved.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

### `runner_outcome_validator_no_reply/validator_io_deadline_releases_worker` — credited

Owners: `tests/suites/runner_outcome_validator_no_reply/check.py; tests/fixtures/validator/no_report.c`. Gaps: G07.

500ms IO deadline preserves one returned verdict and missing second, then releases worker; two independent writes, helper requestedkill9/reap and worker complete.

Scope: Shortened IO deadline. Exact default duration and arbitrary kernel/client faults remain separate.

Observed: 500ms validator I/O deadline retained one allow record and missing second; host validator_no_reply/exit1, helper9062 reapedSIGKILL9 after exhausted1000ms grace and successful termination request. Worker reaped0/done/proceed observed; both independent64-byte seeds become x. CLI1594ms includes helper exit grace; it is not a500ms end-to-end promise.

Exact retained artifact paths, hashes, case command and zero-sleep dispatch record are in this row of `receipt.json`.

## Remaining native qualifications

The 14 opt-ins listed in `receipt.json` remain pending in this default-run audit. Order-barrier mutation sensitivity and live BYOXPC dossier/recovery/reservation/signing evidence receive their own run and inspection.

Native Security failures after apply and initial orchestration-clock nil remain source-only boundaries. Constructed prefix/clock controls establish their supplied inputs and interpretation. The default native cases establish normal signed live association on the selected platform; they supply no spontaneous Security-failure observation.

The sysctl receipt substitutes the native call in a source build. Native filter-ID calibration remains scoped to the selected current cases and the separately dated filter exploration. Native-clock, pause and arm-wait qualification cases are conditional and unselected here.

Large internal writer controls and controlled client foreign-control substitution have their own boundaries. Arbitrary XPC payloads, the native sender/retention cap interval and a genuinely foreign signed recipient remain unobserved unless separately joined.

Dossier scanner/file hashes and independent file/tool reads occur at different times. Actor live binding adds an independently defined process association; these observations keep their individual subjects and times.

Case execution/source-built controls do not turn retained maintainer choices about global cancellation, success beside findings, per-actor withholding or degraded associations into settled behavior changes.

## Override coverage and supplemental controls

The ten-field boundary matrix is `G07-overrides.md`. It preserves the difference between accepted integers, planner applicability, forwarded argv and downstream C refusal. `supplemental-unit-join.json` records exact named late-setup and constructed Security controls, with the enclosing failure kept visible.

Read-time snapshots in `receipt.json` cover the selected assertion owners and listed shared/product sources. The coordinator kept the checkout frozen during this execution; this audit records current source hashes rather than claiming that commit alone identifies the dirty candidate. The final battery receipt and app artifact hashes remain the execution authorities.

