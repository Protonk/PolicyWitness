# witness_contract

Pins the load-bearing behaviors PolicyWitness contracts to provide:
answers in the envelope, attempts in the envelope, the relation between
the two recorded explicitly, validator failures attributed honestly, removed
fields rejected, the specimen dossier collected, the test seam functioning,
and the source-drift guardrail enforcing the audit trail.

Cases assert contract claims independently. The suite reads as a
behavior specification — what PolicyWitness promises, regardless of
the architecture behind it.

## Public phases

`phases` uses the signed CLI with ordinary actions. It unlinks a controlled
file, observes its absence outside PW, then requires fresh planning to withhold
the next native path query while the paired access reports ENOENT. A final
resolvable target requires a fresh validator record and `query_first`. The
reply must retain one worker, distinct collections and all completed phases.
Mutations reject wrong phase association, borrowed records, duplicate IDs,
wrong ordinal, broken completion sequence, a wrong action partition and malformed phase field types.

The same registered case compiles the bounded validator fixture in its owned
temporary target directory and retains a copy with the artifacts. It drives
aggregate timeout and stdout byte cutoff, requiring a received fixture record
before each cutoff so a blocked launch cannot satisfy the control. It asserts
supplied override echoes, real collection stop/reap evidence, unavailable later
predictions, and retained successful attempts. These are driver controls, not
sandbox predictions.

## Native path-query observations

The opt-in `path_query_observations` investigation uses the shipped validator
against a separately signed native target, bypassing host query planning without
changing the app. It pairs default-allow and narrow-deny policies across literal,
subpath and regex predicates, four file operations, and nine path states:
existing, absent leaf/parent, dangling leaf/parent symlink, symlink loop,
non-directory component, non-searchable parent and mode-zero file. Existing
anchor paths accompany each query batch. Separate same-PID controls query and
attempt through unlink/recreate under one fixed policy.

Host `realpath` and errno, raw validator records, syscall results, independent
file state and exact child cleanup remain separate. The case asserts equipment,
framing, coordination and observed effects, not prediction/enforcement agreement
or a universal API outcome. This is exploratory native evidence, not a product
eligibility-rule change or acceptance gate. Targets stay under `/private/tmp`.
See the [fixture](../../fixtures/path_query/README.md) and
[path-query observation account](../../CHANGE-VERIFICATION.md#native-path-query-observations).

The separate opt-in `path_query_integrated` case retains extra native query
receipts against the actual PW worker through a validator wrapper. It forwards
only requested verdicts to the host, so the planner's unavailable results remain
unchanged. Three specimens cover same-worker unlink/recreate, absent-leaf create
and dangling-symlink unlink; independent effects, production consumer validation
and cleanup are checked. The validator's copied executable bytes are unchanged.
This isolates integration relevance while explicitly changing collection timing.

## Native extension boundaries

`extensions` executes the public guide's actual extension example as well as
issuance by an unentitled unapplied actor, native consumption and release
in a selected applied actor, with fresh descriptor identity, bounded bytes and syscall results
on either side of both interventions. Each phase collects its own queries.
Native return values and observed access remain independent evidence.

The same case covers omitted lifecycle actions, same-phase and cross-phase
placement, intervention-only phases, native issuance for missing paths, literal symlink targets
and replacement between issuance and consumption. An independently
held, non-inherited descriptor keeps the removed identity observable while the
worker creates a replacement. Later reads report their actual identity and bytes;
the test does not require release success to revoke access.

`extension_directory` compares directory read-write authority with omitted
consumption, missing predicates, another directory and explicit read authority. Each row first establishes ordinary permissions through
the public fresh-write actions, then restores existing contents and removes the
baseline children before issuance. Separate names serve before-consumption,
during-consumption and post-release attempts. Before-launch absence plus
`create_fresh`'s immediate lstat and exclusive open keep new creation distinct
from opening an earlier child. External final reads happen before reply
interpretation and survive failed assertions; they establish persistence after
release and worker exit. Fresh post-release results have no required pattern.
The absent child keeps its unavailable prediction. A killed-before-publication
write leaves an independently observed effect while withholding its native
result payload. Unknown worker cleanup retains owned staging and a durable
ownership record outside prunable run output.

The opt-in `actors_byoxpc` case uses one owned installed-runner session for
shared lifecycle, directory, ordinary phases, maximum replies and re-delegation.
It independently reads selected and unentitled signatures and entitlement
plists, compares sealed source/installed inventory with registry snapshots,
and checks dossier hashes against installed bytes and the shipped baseline.
An explicit mixed-equipment calibration binds each actor to its static role,
launch PID and live executable inspection; renamed/reordered actors preserve
that association, while a same-selected contrast must fail the expected
unentitled-role assertion. A missing installed selected worker retains an
exact-byte restoration receipt and checks public validation before and after
restore. A service-seal refusal is retained honestly if it precedes role binding.
These controls establish no prediction/enforcement agreement or revocation claim.
Cleanup verifies service removal. Targets stay in owned temporary directories.

`extension_boundaries` compiles two production actor workers with the
[controlled native entrypoints](../../fixtures/extension_controls/README.md).
The clang test build uses `PW_EXTENSION_OBSERVE` outside the inspected app.
These controls establish boundary behavior of those instrumented sources;
they do not interrupt the shipped executable bytes or observe private API internals.
It drives native refusal, absent issue/consume/release APIs, issuing-actor death,
malformed outbound and inbound slots, and interrupted consumption/release through
the CLI. Required worker setup failures cover the core limit, descriptor
metadata, mapping, close, object size and header binding. `authority_setup`
retains the primary operation and independent cleanup cells with actual native
returns and errno. A terminal required failure excludes policy processing and
produces the corresponding actor application assessment. Missing symbols remain
separate operation-availability facts. Independent receipts distinguish death
after the pre-call marker, inside a replacement function, and after the real
native return but before publication; earlier completed evidence survives.

Termination controls keep an issuing actor alive after final completion and
`done`, exceed the gate deadline, or exit abnormally after completion. Dependent
activation requires the source's owned reap. A timeout stays closed after later
cleanup; a natural abnormal exit can satisfy termination without proving clean
completion. Activation, immutable owned-reap and gate-capture ordinals establish
the observed ordering.

The test compares real token bytes with captured output in memory before saving
output, checks argv/environment confinement, production descriptor closure and
buffer erasure, and retains only observations. A deliberately contaminated
in-memory string checks detector sensitivity. Raw tokens never enter fixtures.
The observer's ownership receipt records cleanup; an unconfirmed native child
retains its named channel and recovery record.

`extension_combinations` reads the M rows of the shared comparison matrix. It combines
published issuance with abnormal exit, worker death during mapped-token validation,
same-phase consume failure with omitted release, cross-phase release failure,
and native-call interruption with earlier ordinary observations. Independent
receipts and both readers check each row; Swift comparison tests read the same
expectations. Recipient validation interruption occurs after usable actor setup but before
inbound acknowledgement. Its unresolved delivery and later unactivated visits
remain distinct from terminal authority setup failure.

The ordinary-phase combined control is in `runner_unit` (`PhaseProtocolTests`):
a real validator times out, a substituted termination call fails, and its late
write observes EPIPE while a fresh next-phase validator runs. The retained reply
keeps the first child unreaped and each phase’s records separate; the test owns
independent child cleanup. Rust assembly and the Python consumer/oracle replay
that production-encoded reply. The fixture’s query answers are controlled data.

## Principal policy qualification

`extension_policy_qualification` compiles the principal re-delegation
specimen's B policy with the bundled `sbpl-check` helper, then applies the same
bytes once in a fresh worker through the ordinary single-worker run path with a
baseline `read_fresh` of a test-owned file. The policy denies ordinary reads of
the target and permits issuance only under a consumed read extension; the
denied baseline read, its `deny` prediction and the collection/release chain
are the application observations. An independent run under an ordinary
allowance shows the same target is readable. The bytes live in
[extension_actors.py](../../lib/extension_actors.py), which the principal
acceptance specimen also uses, so the qualified bytes and the submitted bytes
cannot diverge. Retained: the policy and its hash, helper envelope, both run
envelopes, commands and environment. Compile success alone establishes neither
application nor extension-dependent issuance; this case establishes
compilation and application on the recorded equipment only.

## Principal re-delegation acceptance

`actor_compositions` runs public specimens with distinct file contents and
identities across multiple issuers, fan-out, repeated consumes, separate handles,
self-transfer and empty revisits. A second request reverses actor declarations
and consistently renames references. Exact request-to-reply inventories, full
readers, policy hashes and per-process fresh observations must agree. The case
also retains a recipient's compilation failure while unrelated actors continue.
Optional per-actor compiled-profile receipts are checked against the requested
nonce, process, source and captured bytecode; a failed application remains an
unavailable capture. A changed producer context is rejected by the reader.
The positive cases require issuance/consumption/access coverage; a native refusal is
retained as missing coverage, never reclassified as sandbox enforcement failure.
An intervening release is observed without assuming it revokes access.

`extension_redelegation` runs the principal three-actor specimen through
the public CLI against a test-owned file, then a positive calibration and four
narrow contrasts. The witnessing assertions concern the apparatus: `A`, `B` and
`C` are distinct fresh processes whose parent is the host; `B` and `C` applied
the exact qualified policy bytes once (the host's hash, the worker's hash of
the bytes it read and the hash of the source agree) and `A` applied none;
every phase arrived and completed without protocol violations; every ordinary
query names its actor's PID and established `query_first`; every extension
action published; the second delivery is bound to `B`'s issue and `C`'s
consume to that delivery; every launched actor was reaped. The kernel's
answers are recorded, not forced: a published NULL issue, a failed consume or
a denied read passes those assertions. Re-delegation is credited in the report
only when the whole chain published and the fresh reads returned the known
bytes where the baseline reads had failed; otherwise the report names the first
link that broke. The calibration (an unapplied issuer supplying an applied
reader under a simple consumed-extension allowance) must exercise real
issuance, delivery, consumption and access on the host, or the case fails and
the positive coverage is missing. The contrasts omit `B`'s consume, remove
`B`'s issuance allowance, omit `C`'s consume and omit `C`'s extension
predicate; each must still publish its remaining links and must not be
credited, and their observations are retained beside the principal run for
comparison. Retained: every envelope and specimen, the target's identity and
`report.json`.

`actor_timing_qualification` measures the actor profile on the signed
candidate with the actual polling implementation and every actor launched
before the first phase: three matched rounds of one-, three- and eight-actor
specimens sharing one aggregate fresh-read workload distributed over the
actors, a workload at the aggregate action and phase limits over eight actors,
and the principal re-delegation and calibration shapes with five further live
actors servicing bounded ordinary phases. Every run must complete without
budget exhaustion, and each measured interval must leave at least a quarter of
the allowance it is compared against: setup, charged execution, aggregate
collection, the host arrival-to-release proxy, host recipient wait, and setup
plus elapsed schedule execution. The last measurement includes collection time
but excludes final cleanup and the interval between cutoff creation and setup
clock start; it is not a whole-lifetime measurement. Recipient wait does not
measure the worker's custody-acknowledgement or transfer-answer waits. These
intervals come from the reply's schedule, visit timing and transfer records:
host scheduling and publication measurements, never native call latency. The
finite workloads do not establish margins for every admitted composition. The
eight-actor executions keep the chain and calibration assertions. `report.json`
retains the hardware's CPU topology, OS, power and load, every measurement and
margin, and the actor PIDs. A deliberately slow or hung specimen is a different
control; it is not expected to meet this margin.

The same BYOXPC case also launches an owned selected-worker override in a
minimal App Sandbox-signed bundle. An `unapplied` actor cannot read the owned
target while it reads a system file; the ordinary worker and test process can
read the target. The signed entitlement and per-actor instrumented binding are
read independently. A preexisting container is left untouched; a potentially
new container has a durable receipt outside prunable staging, retained until
process cleanup and container absence are established.

## Invariants

- The suite is included in the default battery, including regression guards
  against re-introduction of removed request fields (`instrumentation`) and
  runner modes (`runner.mode=debuggable`).
- `happy_path_baseline.sh` is the regression sentinel — it must pass
  in every run. If it fails, stop and investigate before continuing.
- Tests are stateless: named for what they assert, not for any
  plan-row number.

## Success criteria

- Every test passes.

## Fixtures

- Specimens are generated inline per test.
- `happy_path_baseline` uses a stable `(version 1) (allow default)`
  policy with one file read step.
- `bug_report_returns_verdicts` runs the `(version 2)(deny default)(allow
  file-read-data)` specimen whose worker clock once failed after application.
  Beside the `allow` prediction it requires successful application, no worker
  failure record, the collection/release/acknowledgement chain, the worker's
  published attempt, `query_first` and a confirmed clean worker exit. The open's
  actual rc/errno is retained and validated without requiring success: a
  completed permission failure is valid evidence. Descriptor-derived path
  evidence is checked when present. The `(version 2)(allow default)` neighbour
  is the positive open/path control. Prediction and attempt assertions stay
  independent; neither establishes agreement or universal permission.
- The validator shortfall and decode-failure cases share the checked-in
  `tests/fixtures/validator` transcripts and `runner_validator_failure`
  contract checks. Both require reversed partial verdicts to retain step
  association, all three completed attempts to retain their actual outcomes,
  and the unanswered prediction to have an explicit error and missing reason.
  These two cases also run in the baseline `runner_validator_failure` suite.

## Independent prediction and attempt targets

`prediction_target_is_independent_of_attempt_target` runs two ordinary CLI
specimens with the real validator and no test overrides. Both attempt writes to
two existing files: the policy allows A and denies B. After restoring the same
seed bytes, the second run swaps only the prediction targets. Policy, attempts,
and random step IDs stay fixed. The test reads and retains external file bytes
before decoding PW's JSON: A must change to nonempty data and B must retain every
seed byte in both runs.

The matching run requires an allow answer beside `observation: succeeded` and
a deny answer beside `permission_failure`, both `same_submitted`. The swapped
run retains both answers and attempts with `target_relation:
different_submitted`: the record names the difference and judges nothing.
This checks independent channel routing without promoting pairing to comparability.
Redirecting a validator query to `attempt.target` must fail even if the envelope
continues to echo the requested filter value. The existing classifier and
steered-validator tests retain their separate contracts.

The case checks step identity/order, raw attempt evidence, prediction and
attempt paths, worker/validator completion, and the comparison record.
Shared black-box checks collect both prediction failures rather than stopping
after the first mismatch. `RunCapture` retains each request, raw envelope,
stderr, and capture metadata under `matching/` and `swapped/`; these directories
also contain expectations, byte snapshots, and diagnostics. The case needs the
built app and live XPC; missing equipment fails.

Run it independently with:

```sh
tests/run.sh --case witness_contract/prediction_target_is_independent_of_attempt_target
```

## Create on an existing file

`create_existing_file_preserves_contents` submits two `file/create` attempts
through the CLI, using the real validator and no test overrides. Both targets
already contain distinct random bytes. Policy allows writing one and denies
writing the other. The allowed attempt must succeed with its observed path;
the denied attempt must report `open_failed` with a permission errno. Their
predictions must be allow and deny respectively, with `operation_relation:
unresolved` for the compound create scope.
Both children exit cleanly and the steps retain their identities and evidence.

Before decoding the envelope, the test independently reads both files and
checks that every seed byte and each device/inode pair survived. This protects
create's existing-file semantics: open for writing without truncation,
replacement, or an exclusive-create requirement. The denied-write step also
rejects substituting a read-only open that would preserve the bytes.
`runner_c_worker_harness/create_allow` separately covers creating an absent file.

Artifacts include before/after bytes, `identities.before.json` and
`identities.after.json`, the specimen, expectations, raw envelope, stderr,
capture metadata, and assertion log. Run with:

```sh
tests/run.sh --case witness_contract/create_existing_file_preserves_contents
```

## Predictions before attempts

`queries_precede_attempts` runs an allowed read and unlink of
one file with the real validator and no overrides. Both native predictions must
be allow with `query_first` beside `observation: succeeded`. The test observes file
absence before decoding, and retains later host nonresolution separately as
`sandbox_check.path_diagnostics.realpath_resolved: null`. A later-step unlink
in that same phase is read from `order` and the unlink step's own result
(reading rule 6), pinned by the matrix rows and consumer controls. Cross-phase
sequencing instead requires phase boundary publications; `phases` checks an
unlink/recreate followed by a later native query with its own `query_first`. The
stronger gated observer and deliberate barrier-bypass controls are
separate tests; this ordinary run alone does not replace them.

`queries_use_a_pre_attempt_interval` covers absent/create/unlink,
existing/unlink/read, and unlink/recreate/read plans. An absent planning target
has no query; removing an existing target preserves the earlier native allow
prediction beside ENOENT, state and identity limits. Recreating the path cannot
erase the recorded unlink or certify runtime identity. Create remains a compound
attempt with an unavailable comparison even when the native prediction is allow.

`attempt_effects_wait_for_collection` uses the native bridge's acknowledged query
and emission gates. While stdout collection stays open, independent file reads
must retain the target bytes and the exec helper must have no connection. After
closure, unlink and helper connections must occur; kernel peer PIDs, libproc
ancestry and kqueue exit events identify the helper, worker and host. Only then
does the checker inspect the envelope. This proves the barrier for the observed
unlink and exec effects, not the absence of every possible syscall.

`query_interval_is_not_a_snapshot` removes a target between two acknowledged
native queries. `external_mutation_between_query_and_attempt` removes it after
a native allow receipt while collection remains open. Both retain real native
observations and state/identity limits; test-only mutation knowledge is not a
production attribution. No specific native verdict is required for a missing
target. The resulting ENOENT read is an `other_failure` observation beside the
earlier allow answer; the record relates them and judges nothing.

`max_steps_ordered` runs 256 distinct existing targets, half denied for writing
by literal, and independently checks every file's bytes before decoding.
`deny_default_ordered` checks an allowed and denied read under `(deny default)`.
Both require eligible predictions to be `query_first`; allow/`succeeded` and
deny/`permission_failure` records stay distinct, with no judgment of agreement.

`max_targets_reply_survives` measures admitted 256-action workloads: denied
ASCII reads of 511-byte targets, successful reads of
JSON-escaped paths with observed paths, independent 511-byte query paths
against plain attempt targets, 256 execs with stdout/stderr, and 256 native
execs with 511-byte escaped executable targets and independent query paths,
63-byte step IDs, maximal metadata, live profile capture and 1,023-byte
stdout/stderr streams made of U+0001 (six JSON bytes per input byte).
The explicit phase workload repeats collection across eight boundaries. Fresh-read
workloads use 256 ordinary reads or 254 reads plus consume/release sharing the
same action capacity. They compare returned prefixes and descriptor identities
with independent file observations and require actual native lifecycle results.
These require complete replies and exact targets, outcomes and applicable
output; the control-character workload also requires every prediction to
round-trip through the real validator. Every admitted host reply must stay under
the synthesized maximal reply recorded in `docs/limits.json`
(`runner_reply_maximum`, computed by `runner_unit` from the field-complete reply
fixture with every string at its limit), and the receiver budget must equal three
times that bound rounded up to 4 MiB. The maximal-metadata workload also adds a
conservative receipt allowance (`2 * 4 * ceil(capture / 3) + 4096`, capture from
the manifest) to its host reply, which must still fit under the bound; Swift
independently tests that allowance with maximal slash-heavy bytes. The corpus is evidence that real
replies stay inside a bound that follows the schema, not the source of the bound.
Four refusal workloads submit 32,768-byte query values or filter/attempt labels.
Each requires a host-owned `admission_failure` naming the field, no steps and no
worker or validator subprocess. The label controls place a valid write before
the invalid label and independently require every target to remain unchanged.
Every workload records the host reply's raw bytes and the client's stdout bytes
(the versioned capture carrying the base64 reply, bounded by the receiver budget)
separately and requires an untruncated receiver; refusal replies must be smaller
than 4 KiB. Every echoed request string is
admission-bounded, so these measurements are the evidence for the cap's margin
rather than a closed-form maximum. The exec cases use the independently controlled
`tests/fixtures/exec` helpers and require clang. The byte-stream helper is
checked directly for several fill bytes before the stress workload. Every step execs: the worker
raises its soft descriptor limit pre-apply to fit the four pipe descriptors
each exec step prepares (see `exec_step_descriptors` in `docs/LIMITS.md`).

`max_exec_steps_spawn` runs 256 exec steps of `/usr/bin/true` through the
CLI and requires every attempt to report a clean child. Under launchd's
default soft limit only 62 exec steps could open their pipes before the raise
existed; the case records any step that did not spawn.

The bridge is test equipment selected through the existing executable override;
its direct protocol/native controls live in `validator_bridge`. The opt-in
`order_barrier_mutations` case builds unmodified and patched workers and hosts
outside the inspected app. Baseline component and CLI controls must pass. The
worker wait bypass must fail the ordinary C quiescence assertion; the host early
release must fail the same Swift gate control used by `runner_unit`. Both signed
app copies must produce early unlink and exec effects under the same CLI
effect assertions. The worker bypass publishes arrival, then waits on a test-only
file gate opened by the observer after the validator connects. This places the
fault inside the held collection instead of letting the host reject premature
publication before any collection starts. The direct C control opens that gate
before launch and must still detect the missing worker wait. Hashes, signatures, source patches, command logs and effect receipts
are retained. See [ordering-control applicability and prerequisites](../../CHANGE-VERIFICATION.md#order-barrier-mutation-controls).

The unmodified C scenario must complete its 500 ms hold before release. A bypass
can complete before the first poll: `early_completion` then rejects it immediately,
even with zero held milliseconds and no host release. That observation establishes
premature completion; the baseline supplies the delayed-release coverage.

`validator_spawn_failed_reports_degraded` requires real ENOENT from
`posix_spawn(sb_api_validator)`: the structured native return code, executable
path, operation and nonempty diagnostic, without requiring English wording.
It also requires the mirrored hostile executable path, no validator
subprocess, closed collection with `not_spawned`, unestablished step order,
and an independently changed file after the released write.

## Completed observations after a worker timeout

`worker_post_apply_hang_seam` attempts an allowed write and a denied write,
then uses a post-apply hang longer than the worker deadline and reap grace.
The host reports `runner_timeout` and SIGKILL termination, with CLI/runner
failure, a deadline diagnostic, and both overrides echoed. Independent file
reads must show changed, nonempty bytes for the allowed write and intact seed
bytes for the denied write before the envelope is decoded.

Both completed attempts retain their distinct outcomes, step IDs/order, paths,
errno evidence, matching real validator predictions, `observation: succeeded`
for the allowed write and `permission_failure` for the denied one.
The validator exits cleanly and `partial_steps=false`: failed run completion
does not erase completed observations. The shared checker, timing margins,
and retained artifacts are documented in `runner_outcome_runner_timeout`.
That suite owns the deliberately empty-plan timeout control;
`runner_use_c_worker/worker_timeout_ms_honored` covers a single successful write.

## Attempt in flight at the deadline

`worker_attempt_in_flight_at_deadline` runs three specimens
under `(version 1) (allow default)`:

- `a1`: a FIFO with no writer, then `/etc/hosts`, with `worker_timeout_ms: 2000`.
  Attempt 0 blocks inside the worker until the sentinel deadline; the second
  step is never reached. The envelope records `poll_stop_reason:
  sentinel_deadline`, `termination_request: {rc: 0, signal: 9}`,
  `term_signal: 9`, `reaped: true` and the attempt 0 started progress word.
  The check asserts those witnesses and the echoed override as setup and
  preserves `runner_timeout`, the deadline and SIGKILL error clauses and the
  `signaled` disposition. It then requires
  `runner_sandbox_diagnostics.termination_cause` to equal the
  `HOST_SENTINEL_DEADLINE` constant from `tests/lib/lifecycle_contract.py` and
  forbids `unknown` or any value attributing the signal to the sandbox.
- `a3`: `/etc/hosts`, the FIFO, `/etc/hosts`. The same host witnesses appear with
  progress at attempt index 1, and the completed first step keeps `outcome: ok`,
  `result_source: worker`, `rc: 0`, `order: query_first` and empty limitations.
- `a4`: `/etc/hosts` with `worker_timeout_ms: 300` and
  `worker_post_apply_hang_ms: 800`. The deadline fires and the worker exits 0
  during grace: `sentinel_deadline`, `exit_code: 0`, `done_observed: true`, no
  termination request, `partial_steps: false`, the completed result,
  `runner_timeout`, a `clean_exit` disposition and a null cause all coexist,
  and the error names the deadline with "no termination requested".

The per-step compatibility triples are recorded in `compatibility_triples.json`
without assertion. The lifecycle checks are gated on the reply's response
version (a producer before the record fails as version gating), require an empty finding list from
`tests/lib/lifecycle_oracle.py` on each envelope (written to
`oracle_findings.json`), and assert through `tests/lib/lifecycle_adapter.py`
that `a1` reports `started_without_result` then `not_reached`, `a3` reports
`completed`, `started_without_result`, `not_reached`, and `a4` reports
`completed` with `stop_reason: sentinel_deadline` beside `clean_exit` and a
null cause.

Each FIFO lives in test-owned staging under `/private/tmp` that the check never
opens. Once CLI launch is attempted, staging is removed only when the envelope's
`reaped: true` and valid worker PID witness exit (`tests/lib/worker_exit_witness.py`).
A missing or malformed subprocess record leaves staging retained. `staging.json`
records ownership before capture, and `cleanup.json` records removal or retention.
Setup failure before launch permits removal on the test's own non-spawn observation.
Reused artifact directories are refused before creating staging. Cleanup reporting
failures name the recovery path in stderr and preserve the original failure.

## Death after the native return, before publication

`worker_killed_before_slot_publication` runs one specimen under
`(version 1) (allow default)`: `/etc/hosts`, a `create`
of a fresh file in test-owned staging, then `/etc/hosts` again, with
`worker_kill_before_publish_slot: 1`. The worker's `open(O_CREAT)` returns and
the slot's fields are written; the seam then raises SIGKILL before the slot's
`completed` flag. The check observes the created file itself before reading any
JSON, so the native operation is established independently of the reply.

The reply must withhold what the worker never published: the second step is
`no_completed_result` with `rc: -1`, null `errno`, `result_source: synthetic`,
`missing_reason: slot_incomplete`, lifecycle `started_without_result` and
`observation: unavailable`, and its `error` text makes no claim that the
operation did not run. The completed first step keeps `outcome: ok`,
`result_source: worker` and `observation: succeeded`; the third step is
`not_reached`. Host witnesses establish the position: `poll_stop_reason:
child_reaped`, `term_signal: 9`, `reaped: true`, `done_observed: false`,
`partial_steps: true`, the attempt 1 started progress word and no termination
request; `normalized_outcome` is `runner_failed`, the disposition `signaled`
and the cause `unknown`. The echoed override is setup only. The independent
oracle must return no findings and the adapter must read `completed`,
`started_without_result`, `not_reached`. Staging cleanup follows the in-flight
case's rule: removal requires the envelope's reap witness.

## Failure before published application

`pre_apply_failure_reports_no_policy_verdict` runs the same two-file specimen
twice with real worker/validator binaries. Policy allows one write and denies
the other. The failure run uses `worker_pre_ready_hang_ms=10000` and
`worker_timeout_ms=200`: the delay exceeds the fixed 1s ready-byte wait,
sentinel budget and 1s exit grace by a wide margin. The seam sleeps after
compilation and optional profile capture, before the ready byte and application;
it provides no evidence of compilation failure.

The failure run must retain its subprocess and both overrides while reporting
no observed compile/apply return, allow/deny prediction, completed attempt or
comparison record. The positive control removes only the overrides and requires
allow/`succeeded` and deny/`permission_failure` records. Independent file
reads precede JSON checking: both seeds survive the failure run; the positive
control changes the allowed file and preserves the denied file. Both runs must
avoid a sandbox-termination claim and carry no `deny_signal` or `drift` key on
any step. Missing attempts use the outcome
`no_completed_result`, meaning no completed result, without saying whether the
operation started.

This is the one override-driven case exempt from the exact-outcome assertion in
the `_test_overrides` recipe in [runner guidance](../../../runner/AGENTS.md).
It checks that `normalized_outcome` excludes `ok` and `bad_policy`, and the
spellings `sandbox_apply_failed` and `runner_sandbox_denied` that no constant
defines, rather than pinning one replacement outcome, so it protects the
absence of library/policy claims across outcome renames; classifier tests pin
the mapping. It keeps the recipe's other
assertions: a real failure artifact in the error, both mirrored overrides,
subprocess and missing-step evidence checks, and the un-overridden positive
control. Optional subprocess objects may be omitted or null; a null per-step
`errno` requires key presence.

`check_pre_apply_failure.py` collects separate attribution, step/process evidence,
file-effect, lifecycle and cause assertion groups in `assertions.json`. Lifecycle
groups check polling reason, ready/done observations, termination-call results,
successful reaping and wait-error arrays through the signed CLI. A failing
group does not prevent the positive control from running. Any failing group
fails the case normally; it is never converted into a pass or skip. This case
enforces the [failure evidence contract](../../FAILURE-PROPAGATION-CONTRACT.md).
Consumer checks distinguish missing results from observed failures, retaining
both missing reasons and all simultaneous comparison limits.

Artifacts include `pre_apply/` and `positive_control/` requests, raw envelopes,
stderr, CLI capture metadata and before/after file bytes. The checker also
records `prediction_observations.json`. The consumer checks require
`validator_not_invoked` beside `slot_incomplete`; the validator-failure cases
separately require `validator_no_verdict` beside completed worker observations.
Run with:

```sh
tests/run.sh --case witness_contract/pre_apply_failure_reports_no_policy_verdict
```

## Worker termination

`worker_termination` runs repeated writes that fail with permission-shaped
errors beside successful independent read queries, with both probe plans and
ordered phases. A controlled worker self-signal remains separate from those
attempts; a successful worker exit supplies the positive control. The case
checks unchanged target bytes, per-phase release ordering, raw predictions and
attempts, signal/exit facts, observed reaping, independent consumer recovery
and execution diagnostics. It asserts that collection fields are absent.

## Artifacts

`<run>` is the selected output directory: `tests/out/runs/default` for the
public command, or the explicit `PW_TEST_OUT_DIR`.

- `<run>/suites/witness_contract/<test_id>/artifacts/*`

## Run

```
./tests/run.sh --suite witness_contract
```

Included in the default battery. The catalog shares the two partial-validator
failure cases with `runner_validator_failure`, executing each canonical case once.

`worker_progress_and_failure` checks real-worker success and compilation failure,
plus an external ABI fixture whose unfamiliar operation/code/native-kind values
survive the host, XPC client and controller. Its fixture establishes transport
only; the success run checks independent file contents.

`worker_sparse_failure` checks admitted-size policy transfer interruption and host EPIPE,
a fixture that closes input with or without a report, real C mapping refusal,
and a real self-signal after completed probes with independent file effects.
Its fixtures are built outside the signed app; selected worker paths remain
mirrored in each reply. `worker_progress_and_failure` also compares diagnostic
availability without changing the justified operation/status classification.

## Unfamiliar diagnostic transport

`unfamiliar_diagnostic_transport` builds the ABI fixture outside the selected
app and runs eleven controls through the standard CLI. Two independently
specified codes and distinct payloads must survive, including a known operation
with an unfamiliar code. The mirrored override, worker/validator PIDs, native
fields, diagnostics, failed/incomplete disposition and independent file effects
are checked separately. Absent/unpublished/invalid/incompatible records are not
promoted to accepted evidence. Numeric records survive truncated or invalid
text; an actual EPIPE and a validator UTF-8 fault survive alongside unfamiliar
records. All controls run before the checker reports aggregate failures.

The validator transcript supplies every record, including the allow/native-result
fields; it does not call `sandbox_check`. The worker file change, receiver UTF-8
fault and child disposition are independently observed. The controls establish
preservation of these records, not attribution or comparability between them.

Fixture inputs and limitations are documented in
[diagnostic transport](../../fixtures/diagnostic_transport/README.md).
Direct Swift and Rust receiver controls complement this CLI route. Temporary
known-code filtering or detail-dropping mutations must fail these controls.
The [unfamiliar diagnostic preservation contract](../../FAILURE-PROPAGATION-CONTRACT.md#unfamiliar-diagnostic-preservation-controls)
records the required distinctions and their test owners; running the controls
requires no retained mutation experiment or acceptance output.

## Comparison matrix

`comparison_matrix` runs the three live specimens of
[comparison matrix](../../fixtures/comparison/matrix.json)
through the CLI: S (real validator, twenty-three rows),
B (the validator steered by `stub_validator.py` through
`_test_overrides.validator_executable_path` and the I/O deadline seam; its
records are stub output, so expectations come from submitted scopes and
independent file and permission controls, never native verdicts) and C (a
policy that fails to compile). Before any run it records direct controls:
mode-000 opens and spawns fail with EACCES outside PW, the compiled helpers
exit 0 and 1, absent paths are absent. Every file is recreated before every
specimen, because B unlinks the paths it queries. For each row it asserts the
six-field record, the raw fields named beside it, selection of the same step
by field through `tests/lib/consumer.py`, and the file effects after the run
(bytes unchanged, removed, created, or the one byte `open_write` leaves).
Combined failures are reported together in `matrix-summary.json`. The T row
is owned by `worker_attempt_in_flight_at_deadline`; the same fixture rows are
read by `runner_unit`'s `ComparisonEvidenceTests`.
S09's unsupported attempt is constructed-only coverage of the defensive
comparison classifier. Public requests refuse unsupported attempts before
children; the shared request-contract corpus checks that an earlier valid
create in the refused specimen does not run.

## Specimen dossier

`dossier_witness` checks `data.specimen` against facts read independently of
the envelope: the request bytes the controller held, SHA-256 of the submitted
and applied source, the literal import closure (a specimen with an
`(import "system.sb")` and one with a refused augment), `sysctl` host facts,
and the evidence manifest's entries. Seven examples: an ordinary run, a run
with imports, an applied augment, a refused augment (`failed` with
`augmentation_failed` imports and no client invocation), a policy without
source (`not_applicable`, delivered and refused by the runner as
`bad_request`), controller refusals (missing arguments and absent files produce
`tool_error` and exit 2; invalid JSON and non-object requests produce
`bad_request` and exit 1 with a structured `request_failure`; all retain the
dossier collected so far without creating a temporary request file), and
executable overrides (a byte-identical worker copy records
`match`; different bytes record `mismatch`; a nonexistent, relative, NUL or
overlong path records `unavailable` with its reason; both helper roles are
independent). `request_delivery` must report the held byte count on every
invoked run. The opt-in `dossier_witness_byoxpc` repeats the ordinary example
through an installed BYOXPC copy, where all three
`binaries` records are objects.

The pre-apply case also attempts a real spawn of a nonexistent worker and
requires unchanged files, no worker or validator subprocess, and no ordering
object. Once a worker exists but has not published application, ordering is
all-false with `not_invoked`; no prediction is `query_first`.
